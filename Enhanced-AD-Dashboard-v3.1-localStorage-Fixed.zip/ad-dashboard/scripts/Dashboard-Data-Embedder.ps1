# Dashboard Data Embedder Script
# Integrates collected AD data into the HTML dashboard
# Version: 3.0

param(
    [string]$DataPath = "data",
    [string]$DashboardPath = "dashboard",
    [string]$ConsolidatedDataFile = "",
    [switch]$Verbose
)

if ($Verbose) {
    $VerbosePreference = "Continue"
}

Write-Host "🔄 Dashboard Data Embedder v3.0" -ForegroundColor Cyan
Write-Host "📅 Started: $(Get-Date)" -ForegroundColor Gray
Write-Host "=" * 60 -ForegroundColor DarkGray

# Determine consolidated data file path
if ($ConsolidatedDataFile -eq "") {
    $ConsolidatedDataFile = Join-Path $DataPath "consolidated\consolidated-data.json"
}

# Verify input files exist
if (-not (Test-Path $ConsolidatedDataFile)) {
    Write-Host "❌ Consolidated data file not found: $ConsolidatedDataFile" -ForegroundColor Red
    Write-Host "💡 Please run data collection first to generate the consolidated data file." -ForegroundColor Yellow
    exit 1
}

# Create dashboard directory if it doesn't exist
if (-not (Test-Path $DashboardPath)) {
    New-Item -ItemType Directory -Path $DashboardPath -Force | Out-Null
    Write-Host "📁 Created dashboard directory: $DashboardPath" -ForegroundColor Green
}

# Read consolidated data
Write-Host "📊 Reading consolidated data..." -ForegroundColor Yellow
try {
    $consolidatedJson = Get-Content $ConsolidatedDataFile -Raw -Encoding UTF8
    $consolidatedData = $consolidatedJson | ConvertFrom-Json
    Write-Host "✅ Consolidated data loaded successfully" -ForegroundColor Green
    Write-Host "📈 Data includes $($consolidatedData.metadata.totalDomains) domains with $($consolidatedData.metadata.successfulCollections) successful collections" -ForegroundColor Gray
} catch {
    Write-Host "❌ Error reading consolidated data: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

# Create enhanced JavaScript file with embedded data
Write-Host "📝 Creating enhanced dashboard script..." -ForegroundColor Yellow
$scriptContent = @"
// Enhanced Multi-Domain Active Directory Dashboard
// Version: 3.0 - Enterprise Edition
// Generated: $(Get-Date)
// Data Collection: $($consolidatedData.metadata.generatedOn)

// Embedded consolidated data
window.embeddedConsolidatedData = $consolidatedJson;

// Dashboard configuration
const DASHBOARD_CONFIG = {
    version: '3.0',
    title: 'Enhanced Multi-Domain Active Directory Dashboard',
    refreshInterval: 30000, // 30 seconds
    maxDisplayItems: 1000,
    enableAnimations: true,
    enableNotifications: true,
    defaultView: 'overview',
    domainColors: {
        'corp-hq': '#3498db',
        'sales-region': '#9b59b6',
        'dev-environment': '#e67e22',
        'manufacturing': '#1abc9c',
        'finance-dept': '#e74c3c',
        'research-lab': '#f1c40f'
    }
};

// Dashboard state management
let dashboardState = {
    currentDomain: 'all',
    currentTab: 'overview',
    consolidatedData: null,
    lastUpdate: null,
    isLoading: false,
    notifications: []
};

// Initialize dashboard when page loads
document.addEventListener('DOMContentLoaded', function() {
    console.log('🚀 Enhanced Multi-Domain AD Dashboard Starting...');
    console.log('📊 Dashboard Version:', DASHBOARD_CONFIG.version);
    
    // Use embedded data
    dashboardState.consolidatedData = window.embeddedConsolidatedData;
    dashboardState.lastUpdate = new Date(dashboardState.consolidatedData.metadata.generatedOn);
    
    console.log('✅ Using embedded data, generated:', dashboardState.lastUpdate.toLocaleString());
    console.log('📈 Data summary:', {
        domains: dashboardState.consolidatedData.metadata.totalDomains,
        successful: dashboardState.consolidatedData.metadata.successfulCollections,
        failed: dashboardState.consolidatedData.metadata.failedCollections
    });
    
    // Initialize dashboard
    initializeEnhancedDashboard();
});

// Initialize the enhanced dashboard
function initializeEnhancedDashboard() {
    try {
        console.log('📊 Initializing enhanced dashboard...');
        
        // Update page title
        document.title = DASHBOARD_CONFIG.title;
        
        // Initialize domain selector
        initializeDomainSelector();
        
        // Update metrics
        updateEnhancedMetrics();
        
        // Initialize tabs
        initializeTabSystem();
        
        // Update last refresh time
        updateLastRefreshTime();
        
        // Show success notification
        showNotification('Dashboard loaded successfully with real AD data from ' + 
            dashboardState.consolidatedData.metadata.successfulCollections + ' domains!', 'success');
        
        // Set up auto-refresh if enabled
        if (DASHBOARD_CONFIG.refreshInterval > 0) {
            setInterval(checkForDataUpdates, DASHBOARD_CONFIG.refreshInterval);
        }
        
        console.log('✅ Enhanced dashboard initialization complete!');
        
    } catch (error) {
        console.error('❌ Error initializing enhanced dashboard:', error);
        showNotification('Error loading dashboard: ' + error.message, 'error');
        showErrorState();
    }
}

// Initialize domain selector
function initializeDomainSelector() {
    const domainSelector = document.getElementById('domainSelector');
    if (!domainSelector) return;
    
    // Clear existing options
    domainSelector.innerHTML = '';
    
    // Add "All Domains" option
    const allOption = document.createElement('option');
    allOption.value = 'all';
    allOption.textContent = 'All Domains';
    domainSelector.appendChild(allOption);
    
    // Add individual domain options
    if (dashboardState.consolidatedData.domainData) {
        Object.values(dashboardState.consolidatedData.domainData).forEach(domain => {
            if (domain.status === 'Completed') {
                const option = document.createElement('option');
                option.value = domain.info.id;
                option.textContent = domain.info.name;
                domainSelector.appendChild(option);
            }
        });
    }
    
    // Set up change handler
    domainSelector.addEventListener('change', function() {
        switchDomain(this.value);
    });
}

// Switch domain view
function switchDomain(domainId) {
    console.log('🔄 Switching to domain:', domainId);
    dashboardState.currentDomain = domainId;
    
    // Update metrics for selected domain
    updateEnhancedMetrics();
    
    // Update tab content
    updateTabContent(dashboardState.currentTab);
    
    // Update domain indicator
    updateDomainIndicator();
}

// Update enhanced metric cards
function updateEnhancedMetrics() {
    if (!dashboardState.consolidatedData) {
        console.error('No consolidated data available');
        showErrorState();
        return;
    }
    
    let metricsData;
    
    if (dashboardState.currentDomain === 'all') {
        // Use aggregated summary for all domains
        metricsData = dashboardState.consolidatedData.aggregatedSummary;
    } else {
        // Use specific domain data
        const domainData = dashboardState.consolidatedData.domainData[dashboardState.currentDomain];
        if (domainData && domainData.status === 'Completed') {
            metricsData = domainData.summary;
        } else {
            showNotification('Domain data not available or collection failed', 'warning');
            return;
        }
    }
    
    console.log('📈 Updating metrics for domain:', dashboardState.currentDomain, metricsData);
    
    // Update each metric card with enhanced data
    updateMetricCard('totalUsers', metricsData.totalUsers || 0, {
        active: metricsData.activeUsers || 0,
        disabled: metricsData.disabledUsers || 0,
        locked: metricsData.lockedUsers || 0
    });
    
    updateMetricCard('activeComputers', metricsData.activeComputers || 0, {
        total: metricsData.totalComputers || 0,
        inactive: metricsData.inactiveComputers || 0
    });
    
    updateMetricCard('securityGroups', metricsData.securityGroups || 0, {
        total: metricsData.totalGroups || 0,
        distribution: metricsData.distributionGroups || 0
    });
    
    updateMetricCard('domainControllers', metricsData.domainControllers || 0, {
        globalCatalogs: metricsData.globalCatalogs || 0,
        readOnly: metricsData.readOnlyDCs || 0
    });
}

// Update individual metric card with enhanced information
function updateMetricCard(cardId, primaryValue, additionalData = {}) {
    const card = document.getElementById(cardId);
    if (!card) {
        console.warn('Metric card not found:', cardId);
        return;
    }
    
    const valueElement = card.querySelector('.metric-value');
    const changeElement = card.querySelector('.metric-change');
    
    if (valueElement) {
        valueElement.textContent = formatNumber(primaryValue);
        valueElement.classList.remove('loading', 'error');
        
        // Add animation effect
        if (DASHBOARD_CONFIG.enableAnimations) {
            valueElement.style.transform = 'scale(1.1)';
            setTimeout(() => {
                valueElement.style.transform = 'scale(1)';
            }, 200);
        }
    }
    
    if (changeElement && Object.keys(additionalData).length > 0) {
        // Create detailed breakdown
        const breakdown = Object.entries(additionalData)
            .map(([key, value]) => key + ': ' + formatNumber(value))
            .join(' | ');
        changeElement.textContent = breakdown;
        changeElement.style.fontSize = '10px';
        changeElement.style.color = '#7f8c8d';
    }
    
    console.log('✅ Updated', cardId + ':', primaryValue, additionalData);
}

// Initialize tab system
function initializeTabSystem() {
    const tabButtons = document.querySelectorAll('.tab-btn');
    tabButtons.forEach(button => {
        button.addEventListener('click', function() {
            const tabName = this.getAttribute('data-tab') || 
                           this.onclick.toString().match(/switchTab\('([^']+)'\)/)?.[1];
            if (tabName) {
                switchTab(tabName);
            }
        });
    });
    
    // Initialize with overview tab
    switchTab('overview');
}

// Enhanced tab switching
function switchTab(tabName) {
    console.log('🔄 Switching to tab:', tabName);
    dashboardState.currentTab = tabName;
    
    // Update tab buttons
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    
    // Find and activate the clicked tab
    const activeTab = document.querySelector('[data-tab="' + tabName + '"]') ||
                     Array.from(document.querySelectorAll('.tab-btn')).find(btn => 
                         btn.onclick && btn.onclick.toString().includes(tabName));
    
    if (activeTab) {
        activeTab.classList.add('active');
    }
    
    // Update tab content
    updateTabContent(tabName);
}

// Update tab content with enhanced information
function updateTabContent(tabName) {
    const tabContent = document.getElementById('tabContent');
    if (!tabContent) return;
    
    let content = '';
    
    switch (tabName) {
        case 'overview':
            content = generateEnhancedOverviewContent();
            break;
        case 'users':
            content = generateEnhancedUsersContent();
            break;
        case 'computers':
            content = generateEnhancedComputersContent();
            break;
        case 'security':
            content = generateEnhancedSecurityContent();
            break;
        case 'domains':
            content = generateDomainsContent();
            break;
        case 'reports':
            content = generateReportsContent();
            break;
        default:
            content = '<div>Tab content not available</div>';
    }
    
    tabContent.innerHTML = content;
    
    // Add any interactive elements
    initializeTabInteractions(tabName);
}

// Generate enhanced overview content
function generateEnhancedOverviewContent() {
    if (!dashboardState.consolidatedData) return '<div>No data available</div>';
    
    const metadata = dashboardState.consolidatedData.metadata || {};
    const summary = dashboardState.consolidatedData.aggregatedSummary || {};
    const domainData = dashboardState.consolidatedData.domainData || {};
    
    let domainCards = '';
    Object.values(domainData).forEach(domain => {
        if (domain.info) {
            const statusIcon = domain.status === 'Completed' ? '✅' : '❌';
            const statusColor = domain.status === 'Completed' ? '#27ae60' : '#e74c3c';
            const domainColor = DASHBOARD_CONFIG.domainColors[domain.info.id] || '#3498db';
            
            domainCards += '<div class="domain-card" style="border-left: 4px solid ' + domainColor + ';">' +
                '<div class="domain-header">' +
                    '<h4>' + statusIcon + ' ' + domain.info.name + '</h4>' +
                    '<span class="domain-status" style="color: ' + statusColor + ';">' + domain.status + '</span>' +
                '</div>' +
                '<div class="domain-details">' +
                    '<p><strong>FQDN:</strong> ' + domain.info.fqdn + '</p>' +
                    '<p><strong>Location:</strong> ' + (domain.info.location || 'Not specified') + '</p>' +
                    '<p><strong>Contact:</strong> ' + (domain.info.contact || 'Not specified') + '</p>' +
                '</div>';
            
            if (domain.status === 'Completed' && domain.summary) {
                domainCards += '<div class="domain-metrics">' +
                    '<span>👥 ' + formatNumber(domain.summary.totalUsers) + ' users</span>' +
                    '<span>💻 ' + formatNumber(domain.summary.totalComputers) + ' computers</span>' +
                    '<span>🛡️ ' + formatNumber(domain.summary.totalGroups) + ' groups</span>' +
                    '<span>🖥️ ' + formatNumber(domain.summary.domainControllers) + ' DCs</span>' +
                '</div>';
            }
            
            domainCards += '</div>';
        }
    });
    
    return '<div id="overview-content">' +
        '<h3>📊 Multi-Domain Overview</h3>' +
        '<div class="overview-stats">' +
            '<div class="stat-card">' +
                '<h4>📈 Collection Summary</h4>' +
                '<p><strong>Total Domains:</strong> ' + (metadata.totalDomains || 0) + '</p>' +
                '<p><strong>Successful Collections:</strong> ' + (metadata.successfulCollections || 0) + '</p>' +
                '<p><strong>Failed Collections:</strong> ' + (metadata.failedCollections || 0) + '</p>' +
                '<p><strong>Collection Duration:</strong> ' + (metadata.collectionDuration || 0) + ' minutes</p>' +
            '</div>' +
            '<div class="stat-card">' +
                '<h4>👥 User Statistics</h4>' +
                '<p><strong>Total Users:</strong> ' + formatNumber(summary.totalUsers || 0) + '</p>' +
                '<p><strong>Active Users:</strong> ' + formatNumber(summary.activeUsers || 0) + '</p>' +
                '<p><strong>Disabled Users:</strong> ' + formatNumber(summary.disabledUsers || 0) + '</p>' +
                '<p><strong>Locked Users:</strong> ' + formatNumber(summary.lockedUsers || 0) + '</p>' +
            '</div>' +
            '<div class="stat-card">' +
                '<h4>💻 Computer Statistics</h4>' +
                '<p><strong>Total Computers:</strong> ' + formatNumber(summary.totalComputers || 0) + '</p>' +
                '<p><strong>Active Computers:</strong> ' + formatNumber(summary.activeComputers || 0) + '</p>' +
                '<p><strong>Inactive Computers:</strong> ' + formatNumber(summary.inactiveComputers || 0) + '</p>' +
            '</div>' +
            '<div class="stat-card">' +
                '<h4>🛡️ Security Overview</h4>' +
                '<p><strong>Security Groups:</strong> ' + formatNumber(summary.securityGroups || 0) + '</p>' +
                '<p><strong>Distribution Groups:</strong> ' + formatNumber(summary.distributionGroups || 0) + '</p>' +
                '<p><strong>Domain Controllers:</strong> ' + formatNumber(summary.domainControllers || 0) + '</p>' +
                '<p><strong>Global Catalogs:</strong> ' + formatNumber(summary.globalCatalogs || 0) + '</p>' +
            '</div>' +
        '</div>' +
        '<h3>🏢 Domain Status</h3>' +
        '<div class="domains-grid">' + domainCards + '</div>' +
        '<div class="last-refresh">Last updated: ' + new Date(metadata.generatedOn || new Date()).toLocaleString() + '</div>' +
    '</div>';
}

// Generate enhanced users content
function generateEnhancedUsersContent() {
    const summary = getCurrentDomainSummary();
    if (!summary) return '<div>No user data available</div>';
    
    return '<div>' +
        '<h3>👥 User Management</h3>' +
        '<div class="user-stats-grid">' +
            '<div class="user-stat-card">' +
                '<div class="stat-icon">👥</div>' +
                '<div class="stat-info">' +
                    '<h4>' + formatNumber(summary.totalUsers || 0) + '</h4>' +
                    '<p>Total Users</p>' +
                '</div>' +
            '</div>' +
            '<div class="user-stat-card active">' +
                '<div class="stat-icon">✅</div>' +
                '<div class="stat-info">' +
                    '<h4>' + formatNumber(summary.activeUsers || 0) + '</h4>' +
                    '<p>Active Users</p>' +
                '</div>' +
            '</div>' +
            '<div class="user-stat-card disabled">' +
                '<div class="stat-icon">❌</div>' +
                '<div class="stat-info">' +
                    '<h4>' + formatNumber(summary.disabledUsers || 0) + '</h4>' +
                    '<p>Disabled Users</p>' +
                '</div>' +
            '</div>' +
            '<div class="user-stat-card locked">' +
                '<div class="stat-icon">🔒</div>' +
                '<div class="stat-info">' +
                    '<h4>' + formatNumber(summary.lockedUsers || 0) + '</h4>' +
                    '<p>Locked Users</p>' +
                '</div>' +
            '</div>' +
        '</div>' +
        '<div class="content-section">' +
            '<h4>📊 User Analysis</h4>' +
            '<p>Active user percentage: <strong>' + 
                Math.round((summary.activeUsers / summary.totalUsers) * 100) + '%</strong></p>' +
            '<p>Disabled user percentage: <strong>' + 
                Math.round((summary.disabledUsers / summary.totalUsers) * 100) + '%</strong></p>' +
            '<div class="info-box">' +
                '<p><em>Detailed user information, password policies, and account management tools would be displayed here in a production environment.</em></p>' +
            '</div>' +
        '</div>' +
    '</div>';
}

// Generate enhanced computers content
function generateEnhancedComputersContent() {
    const summary = getCurrentDomainSummary();
    if (!summary) return '<div>No computer data available</div>';
    
    return '<div>' +
        '<h3>💻 Computer Management</h3>' +
        '<div class="computer-stats-grid">' +
            '<div class="computer-stat-card">' +
                '<div class="stat-icon">💻</div>' +
                '<div class="stat-info">' +
                    '<h4>' + formatNumber(summary.totalComputers || 0) + '</h4>' +
                    '<p>Total Computers</p>' +
                '</div>' +
            '</div>' +
            '<div class="computer-stat-card active">' +
                '<div class="stat-icon">🟢</div>' +
                '<div class="stat-info">' +
                    '<h4>' + formatNumber(summary.activeComputers || 0) + '</h4>' +
                    '<p>Active Computers</p>' +
                '</div>' +
            '</div>' +
            '<div class="computer-stat-card inactive">' +
                '<div class="stat-icon">🔴</div>' +
                '<div class="stat-info">' +
                    '<h4>' + formatNumber(summary.inactiveComputers || 0) + '</h4>' +
                    '<p>Inactive Computers</p>' +
                '</div>' +
            '</div>' +
        '</div>' +
        '<div class="content-section">' +
            '<h4>📊 Computer Analysis</h4>' +
            '<p>Active computer percentage: <strong>' + 
                Math.round((summary.activeComputers / summary.totalComputers) * 100) + '%</strong></p>' +
            '<div class="info-box">' +
                '<p><em>Computer inventory, operating system distribution, patch status, and hardware management tools would be displayed here.</em></p>' +
            '</div>' +
        '</div>' +
    '</div>';
}

// Generate enhanced security content
function generateEnhancedSecurityContent() {
    const summary = getCurrentDomainSummary();
    if (!summary) return '<div>No security data available</div>';
    
    return '<div>' +
        '<h3>🔒 Security Overview</h3>' +
        '<div class="security-stats-grid">' +
            '<div class="security-stat-card">' +
                '<div class="stat-icon">🛡️</div>' +
                '<div class="stat-info">' +
                    '<h4>' + formatNumber(summary.securityGroups || 0) + '</h4>' +
                    '<p>Security Groups</p>' +
                '</div>' +
            '</div>' +
            '<div class="security-stat-card">' +
                '<div class="stat-icon">📧</div>' +
                '<div class="stat-info">' +
                    '<h4>' + formatNumber(summary.distributionGroups || 0) + '</h4>' +
                    '<p>Distribution Groups</p>' +
                '</div>' +
            '</div>' +
            '<div class="security-stat-card">' +
                '<div class="stat-icon">🖥️</div>' +
                '<div class="stat-info">' +
                    '<h4>' + formatNumber(summary.domainControllers || 0) + '</h4>' +
                    '<p>Domain Controllers</p>' +
                '</div>' +
            '</div>' +
            '<div class="security-stat-card">' +
                '<div class="stat-icon">🌐</div>' +
                '<div class="stat-info">' +
                    '<h4>' + formatNumber(summary.globalCatalogs || 0) + '</h4>' +
                    '<p>Global Catalogs</p>' +
                '</div>' +
            '</div>' +
        '</div>' +
        '<div class="content-section">' +
            '<h4>🔐 Security Analysis</h4>' +
            '<p>Security groups ratio: <strong>' + 
                Math.round((summary.securityGroups / summary.totalGroups) * 100) + '%</strong></p>' +
            '<div class="info-box">' +
                '<p><em>Security policies, compliance reports, audit logs, and access control management would be displayed here.</em></p>' +
            '</div>' +
        '</div>' +
    '</div>';
}

// Helper function to get current domain summary
function getCurrentDomainSummary() {
    if (!dashboardState.consolidatedData) return null;
    
    if (dashboardState.currentDomain === 'all') {
        return dashboardState.consolidatedData.aggregatedSummary;
    } else {
        const domainData = dashboardState.consolidatedData.domainData[dashboardState.currentDomain];
        return domainData && domainData.status === 'Completed' ? domainData.summary : null;
    }
}

// Initialize tab interactions
function initializeTabInteractions(tabName) {
    // Add any tab-specific interactive elements here
    console.log('Initializing interactions for tab:', tabName);
}

// Update domain indicator
function updateDomainIndicator() {
    const indicator = document.getElementById('domainIndicator');
    if (indicator) {
        if (dashboardState.currentDomain === 'all') {
            indicator.textContent = 'All Domains';
            indicator.style.color = '#3498db';
        } else {
            const domainData = dashboardState.consolidatedData.domainData[dashboardState.currentDomain];
            if (domainData) {
                indicator.textContent = domainData.info.name;
                indicator.style.color = DASHBOARD_CONFIG.domainColors[domainData.info.id] || '#3498db';
            }
        }
    }
}

// Format number with commas
function formatNumber(num) {
    if (num === null || num === undefined || isNaN(num)) return '0';
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

// Update last refresh time
function updateLastRefreshTime() {
    const refreshElements = document.querySelectorAll('.last-refresh');
    const timestamp = dashboardState.lastUpdate || new Date();
    const formattedTime = timestamp.toLocaleString();
    
    refreshElements.forEach(element => {
        element.textContent = 'Last updated: ' + formattedTime;
    });
}

// Show error state
function showErrorState() {
    const metricCards = document.querySelectorAll('.metric-value');
    metricCards.forEach(card => {
        card.textContent = 'Error';
        card.classList.remove('loading');
        card.classList.add('error');
    });
}

// Check for data updates (placeholder for future auto-refresh functionality)
function checkForDataUpdates() {
    // This would check for updated data files in a real implementation
    console.log('Checking for data updates...');
}

// Refresh data function
function refreshData() {
    console.log('🔄 Refresh requested');
    showNotification('To refresh data, please run the data collection script to gather new AD information.', 'info');
}

// Enhanced notification system
function showNotification(message, type, duration = 5000) {
    type = type || 'info';
    
    // Create notification element
    const notification = document.createElement('div');
    notification.className = 'notification notification-' + type;
    
    // Add icon based on type
    const icons = {
        success: '✅',
        error: '❌',
        warning: '⚠️',
        info: 'ℹ️'
    };
    
    notification.innerHTML = '<span class="notification-icon">' + (icons[type] || icons.info) + '</span>' +
                           '<span class="notification-message">' + message + '</span>' +
                           '<button class="notification-close" onclick="this.parentElement.remove()">×</button>';
    
    // Style the notification
    const styles = {
        success: { background: '#27ae60', color: 'white' },
        error: { background: '#e74c3c', color: 'white' },
        warning: { background: '#f39c12', color: 'white' },
        info: { background: '#3498db', color: 'white' }
    };
    
    const style = styles[type] || styles.info;
    Object.assign(notification.style, {
        position: 'fixed',
        top: '20px',
        right: '20px',
        padding: '15px 20px',
        borderRadius: '8px',
        boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
        zIndex: '1000',
        maxWidth: '400px',
        background: style.background,
        color: style.color,
        display: 'flex',
        alignItems: 'center',
        gap: '10px',
        fontSize: '14px',
        fontWeight: '500'
    });
    
    // Add to page
    document.body.appendChild(notification);
    
    // Auto-remove after duration
    if (duration > 0) {
        setTimeout(() => {
            if (notification.parentNode) {
                notification.style.opacity = '0';
                notification.style.transform = 'translateX(100%)';
                setTimeout(() => {
                    if (notification.parentNode) {
                        notification.parentNode.removeChild(notification);
                    }
                }, 300);
            }
        }, duration);
    }
    
    // Add to state
    dashboardState.notifications.push({
        message: message,
        type: type,
        timestamp: new Date()
    });
}

console.log('📊 Enhanced Multi-Domain AD Dashboard Script Loaded - Ready!');
console.log('🎯 Dashboard Configuration:', DASHBOARD_CONFIG);
"@

# Save the enhanced JavaScript file
$scriptFile = Join-Path $DashboardPath "script.js"
Set-Content $scriptFile -Value $scriptContent -Encoding UTF8
Write-Host "💾 Enhanced dashboard script created: $scriptFile" -ForegroundColor Green

# Calculate script size
$scriptSize = [math]::Round((Get-Item $scriptFile).Length / 1KB, 2)
Write-Host "📊 Script size: $scriptSize KB" -ForegroundColor Cyan

Write-Host ""
Write-Host "✅ DASHBOARD DATA EMBEDDING COMPLETED!" -ForegroundColor Green
Write-Host "🌐 Dashboard is ready with embedded AD data!" -ForegroundColor Yellow
Write-Host "📂 Dashboard files location: $DashboardPath" -ForegroundColor Cyan
Write-Host ""
Write-Host "🎯 Next steps:" -ForegroundColor Magenta
Write-Host "   1. Ensure the HTML dashboard file is in the dashboard directory" -ForegroundColor Gray
Write-Host "   2. Open the dashboard HTML file in a web browser" -ForegroundColor Gray
Write-Host "   3. Verify that all data is displaying correctly" -ForegroundColor Gray
Write-Host ""

