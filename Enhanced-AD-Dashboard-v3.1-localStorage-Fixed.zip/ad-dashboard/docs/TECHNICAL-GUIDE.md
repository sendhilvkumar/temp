# Technical Guide - Enhanced Multi-Domain Active Directory Dashboard

## Table of Contents
1. [Architecture Overview](#architecture-overview)
2. [Data Collection Process](#data-collection-process)
3. [Dashboard Implementation](#dashboard-implementation)
4. [Configuration Management](#configuration-management)
5. [Data Visualization](#data-visualization)
6. [Customization and Extension](#customization-and-extension)
7. [Security Considerations](#security-considerations)
8. [Performance Tuning](#performance-tuning)

## Architecture Overview

### Core Components

#### 1. Data Collection Engine (PowerShell)
- **Purpose**: Gathers data from Active Directory domains
- **Technology**: PowerShell 5.0+ with Active Directory module
- **Key Scripts**:
  - `Enhanced-Multi-Domain-AD-Collector.ps1`: Main collection script
  - `Dashboard-Data-Embedder.ps1`: Integrates data into HTML
  - `Run-Enhanced-AD-Dashboard.bat`: Execution wrapper

#### 2. Configuration Manager (HTML/JS)
- **Purpose**: Provides a web-based interface for domain configuration
- **Technology**: HTML5, CSS3, JavaScript (ES6+)
- **Key Files**:
  - `config.html`: Configuration UI
  - `config-manager.js`: Configuration logic

#### 3. Data Storage (JSON)
- **Purpose**: Stores collected data for dashboard consumption
- **Format**: JSON (JavaScript Object Notation)
- **Key Files**:
  - `data/consolidated/consolidated-data.json`: Aggregated data
  - `data/individual/*.json`: Per-domain data files

#### 4. Dashboard Frontend (HTML/CSS/JS)
- **Purpose**: Displays data and provides interactive features
- **Technology**: HTML5, CSS3, JavaScript (ES6+), Chart.js
- **Key Files**:
  - `index.html`: Main dashboard UI
  - `script.js`: Core dashboard logic
  - `visualization.js`: Charting and reporting

### Data Flow Diagram
```mermaid
graph TD
    A[Configuration Manager] -->|Saves config| B(Configuration File)
    B -->|Loads config| C(PowerShell Collector)
    C -->|Queries| D{Active Directory Domains}
    D -->|Returns data| C
    C -->|Generates| E(JSON Data Files)
    E -->|Embedded into| F(HTML Dashboard)
    G[User] -->|Opens| F
    F -->|Displays data| G
```

### Technology Stack

#### Frontend
- **HTML5**: Semantic structure and content
- **CSS3**: Responsive design, animations, and styling
- **JavaScript (ES6+)**: Interactive features, data processing, and UI updates
- **Chart.js**: Data visualization and charting library

#### Backend (Data Collection)
- **PowerShell**: Core scripting language for AD interaction
- **Active Directory Module**: Provides cmdlets for AD queries
- **JSON**: Data interchange format

#### Key Design Principles
- **Offline First**: Operates without internet after initial setup
- **Modularity**: Separate components for collection, configuration, and display
- **Scalability**: Designed to handle up to 6 domains with large datasets
- **Extensibility**: Easy to customize and extend with new features
- **User Experience**: Intuitive interface with responsive design

## Data Collection Process

### PowerShell Scripts

#### `Enhanced-Multi-Domain-AD-Collector.ps1`
This is the main script responsible for data collection.

**Execution Flow**:
1. **Initialization**: Loads configuration and sets up logging
2. **Domain Iteration**: Loops through each enabled domain
3. **Connectivity Test**: Verifies connection to domain controller
4. **Data Collection**: Executes AD queries for users, computers, groups, and DCs
5. **Data Aggregation**: Consolidates data from all domains
6. **JSON Generation**: Creates individual and consolidated JSON files
7. **Error Handling**: Catches and logs errors during collection

**Key Functions**:
- `Get-ADDomainData`: Collects data for a single domain
- `Get-ADUsers`, `Get-ADComputers`, `Get-ADGroups`, `Get-ADDomainControllers`: Specific data collection functions
- `Export-JsonData`: Saves data to JSON files
- `Write-Log`: Custom logging function

#### `Dashboard-Data-Embedder.ps1`
This script integrates the collected data into the HTML dashboard files.

**Execution Flow**:
1. **Load Data**: Reads the consolidated JSON data file
2. **Load HTML**: Reads the `index.html` and `config.html` files
3. **Data Embedding**: Injects JSON data into a `<script>` tag in the HTML
4. **Save HTML**: Overwrites the original HTML files with the updated versions

**Embedding Mechanism**:
```html
<script>
  window.embeddedConsolidatedData = { /* JSON data here */ };
</script>
```
This allows the dashboard to load data without additional file requests, ensuring offline functionality.

#### `Run-Enhanced-AD-Dashboard.bat`
This batch file simplifies the execution process.

**Execution Flow**:
1. **Set PowerShell Path**: Locates PowerShell executable
2. **Run Collector**: Executes the main collection script
3. **Run Embedder**: Executes the data embedding script
4. **Display Status**: Shows success or failure messages

### Data Structure (JSON)

#### Consolidated Data File (`consolidated-data.json`)
```json
{
  "metadata": {
    "version": "3.0",
    "generatedOn": "2024-10-27T10:00:00Z",
    "collectionDuration": 15,
    "totalDomains": 6,
    "successfulCollections": 6,
    "failedCollections": 0
  },
  "aggregatedSummary": {
    "totalUsers": 15000,
    "activeUsers": 14500,
    "disabledUsers": 450,
    "lockedUsers": 50,
    "totalComputers": 12000,
    "activeComputers": 11000,
    "inactiveComputers": 1000,
    "totalGroups": 8000,
    "securityGroups": 6000,
    "distributionGroups": 2000,
    "domainControllers": 24,
    "globalCatalogs": 12
  },
  "domainData": {
    "corp-hq": {
      "info": { /* Domain info */ },
      "summary": { /* Domain summary */ },
      "status": "Completed",
      "error": null
    },
    "sales-region": { /* ... */ }
  }
}
```

#### Individual Domain File (`corp-hq.json`)
```json
{
  "info": {
    "id": "corp-hq",
    "name": "Corporate Headquarters",
    "fqdn": "corp.company.com",
    /* ... */
  },
  "summary": {
    "totalUsers": 5000,
    /* ... */
  },
  "data": {
    "users": [ { /* User object */ } ],
    "computers": [ { /* Computer object */ } ],
    "groups": [ { /* Group object */ } ],
    "domainControllers": [ { /* DC object */ } ]
  },
  "status": "Completed",
  "error": null
}
```

## Dashboard Implementation

### HTML Structure

#### `index.html`
- **Header**: Contains title, domain selector, and refresh button
- **Metrics Grid**: Displays key metric cards
- **Tabs Container**: Manages tab navigation and content
- **Tab Content**: Dynamically updated with selected tab information
- **Scripts**: Loads Chart.js, `script.js`, and `visualization.js`

#### `config.html`
- **Header**: Contains title and save/back buttons
- **Tabs Container**: Manages configuration tabs
- **Domain Grid**: Displays domain configuration cards
- **Global Settings**: Form for global configuration
- **Import/Export**: Buttons for configuration management
- **Help**: Documentation and troubleshooting information

### CSS Styling
- **Responsive Design**: Uses media queries for different screen sizes
- **CSS Variables**: For easy theme and color management
- **Flexbox and Grid**: For modern layout and alignment
- **Animations and Transitions**: For a smooth user experience
- **Fallback Styles**: For browsers without full CSS3 support

### JavaScript Logic

#### `script.js` (Core Dashboard)
- **`DashboardController`**: Main controller for initialization and data loading
- **`DataManager`**: Handles data loading, caching, and domain filtering
- **`UIManager`**: Manages UI updates, tab switching, and event listeners
- **`MetricsManager`**: Updates key metric cards
- **`ContentGenerator`**: Generates HTML content for each tab
- **`NotificationManager`**: Displays user notifications
- **`Utils`**: Utility functions for formatting and calculations

#### `config-manager.js` (Configuration)
- **`ConfigManager`**: Manages domain and global settings
- **`ConfigUtils`**: Utility functions for validation and generation
- **Event Handlers**: For saving, importing, exporting, and testing
- **Local Storage**: Persists configuration in the browser

#### `visualization.js` (Charts and Reports)
- **`VisualizationManager`**: Creates and manages charts using Chart.js
- **`ReportingManager`**: Generates and exports reports
- **Chart.js Integration**: Provides advanced data visualization
- **Fallback Charts**: Simple HTML/CSS charts when Chart.js is unavailable
- **Data Export**: Logic for CSV, JSON, HTML, and PDF export

## Configuration Management

### Configuration File (`ad-dashboard-config.json`)
- **Format**: JSON
- **Location**: Exported/imported via configuration interface
- **Structure**:
  - `domains`: Array of domain configuration objects
  - `globalSettings`: Object with collection and dashboard settings
  - `metadata`: Version and export information

### Local Storage
- **Key**: `adDashboardConfig`
- **Purpose**: Persists configuration changes in the browser
- **Mechanism**: Automatically saves on any configuration change
- **Benefit**: Retains settings between sessions without manual export/import

### Validation

#### Frontend Validation (JavaScript)
- **FQDN Format**: Regular expression validation
- **Email Format**: Regular expression validation
- **Unique IDs**: Checks for duplicate domain IDs
- **Required Fields**: Ensures required fields are not empty

#### Backend Validation (PowerShell)
- **Connectivity Test**: Verifies domain accessibility
- **Credential Check**: Validates authentication credentials
- **Permission Check**: Ensures read access to Active Directory

## Data Visualization

### Chart.js Integration
- **Library**: Chart.js (loaded from CDN)
- **Purpose**: Provides interactive and animated charts
- **Chart Types Used**:
  - Doughnut (Domain Distribution)
  - Bar (User Status)
  - Pie (Computer Activity)
  - Line (Trends)

### Fallback Mechanism
- **Condition**: Chart.js library not loaded (e.g., no internet)
- **Implementation**: Simple HTML/CSS charts are displayed instead
- **Benefit**: Ensures basic visualization is always available

### Chart Creation Process
1. **Container**: A `<canvas>` element is created in the HTML
2. **Data Preparation**: JavaScript functions prepare data for the chart
3. **Chart Instantiation**: `new Chart(ctx, config)` creates the chart
4. **Options**: Configuration object defines chart type, data, and options
5. **Rendering**: Chart.js renders the chart on the canvas

## Customization and Extension

### Adding New Metrics
1. **PowerShell**: Modify `Get-ADDomainData` to collect the new metric
2. **JSON**: Add the new metric to the data structure
3. **JavaScript**: 
   - Update `MetricsManager` to display the new metric card
   - Add the metric to `ContentGenerator` for tab display
4. **HTML**: Add a new metric card container to `index.html`

### Creating New Reports
1. **JavaScript**: 
   - Add a new report type to `ReportingManager`
   - Create a new function to generate the report HTML
   - Add the new report type to the dropdown in `reporting-interface.html`
2. **HTML**: Update the reporting interface with the new option

### Changing Visual Style
- **CSS Variables**: Modify `:root` variables in the CSS for easy theme changes
- **Colors**: Update `domainColors` in `DASHBOARD_CONFIG` in `script.js`
- **Layout**: Adjust Flexbox and Grid properties in the CSS

## Security Considerations

### Data at Rest
- **JSON Files**: Stored in plain text. Consider file system encryption (e.g., BitLocker) if required.
- **Local Storage**: Stored in browser profile. Secure the user profile.

### Data in Transit
- **Internal Network**: Data collection occurs over the local network. Ensure network security.
- **No Cloud**: No data is transmitted to external services.

### Script Security
- **PowerShell Execution Policy**: Set to `RemoteSigned` to prevent unsigned scripts from running.
- **Code Review**: Review all scripts before execution.
- **Least Privilege**: Run collection scripts with a user account that has only read permissions to Active Directory.

## Performance Tuning

### Data Collection
- **Parallel Collection**: Enable for faster collection from multiple domains.
- **Data Limits**: Reduce the number of objects collected for very large domains.
- **Targeted DCs**: Modify scripts to target specific domain controllers.

### Dashboard Frontend
- **Debouncing**: Used for window resize events to prevent excessive re-rendering.
- **Virtualization**: For very large tables, consider implementing a virtual scrolling library.
- **Code Splitting**: For very large applications, consider splitting JavaScript into smaller chunks.

---

This technical guide provides an in-depth look at the architecture and implementation of the Enhanced Multi-Domain Active Directory Dashboard. For user-facing instructions, refer to the User Guide.

