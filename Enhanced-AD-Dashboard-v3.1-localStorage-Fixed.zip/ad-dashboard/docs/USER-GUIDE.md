# User Guide - Enhanced Multi-Domain Active Directory Dashboard

## Table of Contents
1. [Getting Started](#getting-started)
2. [Dashboard Overview](#dashboard-overview)
3. [Configuration Management](#configuration-management)
4. [Data Collection](#data-collection)
5. [Using the Dashboard](#using-the-dashboard)
6. [Generating Reports](#generating-reports)
7. [Data Export](#data-export)
8. [Troubleshooting](#troubleshooting)

## Getting Started

### First Time Setup

#### Prerequisites Check
Before using the dashboard, ensure you have:
- Windows computer with PowerShell 5.0+
- Active Directory PowerShell module (RSAT)
- Network access to your Active Directory domains
- Read permissions to Active Directory
- Modern web browser

#### Initial Configuration
1. **Extract Files**: Unzip the dashboard package to a folder like `C:\AD-Dashboard`
2. **Open Configuration**: Navigate to the dashboard folder and open `config.html` in your web browser
3. **Configure Domains**: Set up your Active Directory domains (detailed steps below)
4. **Test Connectivity**: Verify each domain is accessible
5. **Save Settings**: Save your configuration

### Quick Start Checklist
- [ ] Extract dashboard files
- [ ] Configure at least one domain
- [ ] Test domain connectivity
- [ ] Run data collection script
- [ ] Open dashboard in browser
- [ ] Verify data is displayed

## Dashboard Overview

### Main Interface Components

#### Header Section
- **Dashboard Title**: "Enhanced Multi-Domain Active Directory Dashboard"
- **Domain Selector**: Dropdown to filter by specific domain or view all domains
- **Refresh Button**: Manually refresh data (note: requires running collection script)

#### Navigation Tabs
- **📊 Overview**: High-level summary across all domains
- **👥 Users**: User account analysis and statistics
- **💻 Computers**: Computer inventory and activity
- **🔒 Security**: Security groups and domain controllers
- **🏢 Domains**: Individual domain details and management
- **📋 Reports**: Advanced reporting and analytics

#### Key Metrics Cards
Four main metric cards display:
- **Total Users**: Count of all user accounts
- **Active Computers**: Number of active computer accounts
- **Security Groups**: Count of security groups
- **Domain Controllers**: Number of domain controllers

### Visual Elements

#### Color Coding
Each domain has a unique color for easy identification:
- Corporate HQ: Blue (#3498db)
- Sales Region: Purple (#9b59b6)
- Development: Orange (#e67e22)
- Manufacturing: Teal (#1abc9c)
- Finance: Red (#e74c3c)
- Research: Yellow (#f1c40f)

#### Status Indicators
- ✅ **Green**: Successful data collection
- ❌ **Red**: Failed data collection
- ⚠️ **Yellow**: Warning or partial data
- 🔄 **Blue**: In progress or loading

## Configuration Management

### Accessing Configuration
1. Open `config.html` in your web browser
2. The configuration interface has four main tabs:
   - **🏢 Domain Configuration**: Set up individual domains
   - **⚙️ Global Settings**: Configure collection and dashboard behavior
   - **📁 Import/Export**: Backup and restore configurations
   - **❓ Help**: Documentation and troubleshooting

### Domain Configuration

#### Adding a New Domain
1. Click the "➕ Add New Domain" button
2. Fill in the required information:

**Basic Information**
- **Domain ID**: Unique identifier (lowercase, no spaces)
  - Example: `corp-hq`, `sales-west`, `dev-lab`
- **Domain Name**: Friendly display name
  - Example: "Corporate Headquarters", "Sales West Region"
- **FQDN**: Fully qualified domain name
  - Example: `corp.company.com`, `sales.company.com`

**Additional Details**
- **Description**: Brief description of the domain's purpose
- **Location**: Physical or logical location
- **Contact Email**: Administrator contact information
- **Priority**: Collection order (1 = highest priority)
- **Color**: Visual identifier for charts and displays

#### Domain Configuration Example
```
Domain ID: corp-hq
Domain Name: Corporate Headquarters
FQDN: corp.company.com
Description: Main corporate domain with executive and administrative users
Location: New York, NY
Contact: IT-Admin@corp.company.com
Priority: 1
Color: Blue (#3498db)
```

#### Testing Domain Connectivity
1. After configuring a domain, click "🔍 Test Connection"
2. The system will verify:
   - FQDN resolution
   - Network connectivity
   - Active Directory accessibility
3. Results are displayed with color-coded status:
   - ✅ Green: Connection successful
   - ❌ Red: Connection failed

#### Managing Existing Domains
- **Edit**: Modify any field and changes are automatically saved
- **📋 Duplicate**: Create a copy of an existing domain configuration
- **🗑️ Remove**: Delete a domain configuration (requires confirmation)
- **Enable/Disable**: Toggle whether a domain is included in data collection

### Global Settings

#### Collection Settings
Configure how data is collected from domains:

**Timeouts and Retries**
- **Collection Timeout**: Maximum time to wait for each domain (60-3600 seconds)
- **Retry Attempts**: Number of retry attempts for failed collections (1-10)
- **Parallel Collection**: Enable simultaneous collection from multiple domains

**Data Limits**
- **Maximum Users per Domain**: Limit user objects collected (100-10000)
- **Maximum Computers per Domain**: Limit computer objects collected (100-10000)
- **Maximum Groups per Domain**: Limit group objects collected (50-5000)

#### Dashboard Settings
Customize dashboard appearance and behavior:

**Display Options**
- **Dashboard Title**: Custom title for your dashboard
- **Refresh Interval**: How often to check for new data (5-1440 minutes)
- **Enable Real-time Updates**: Automatically refresh when new data is available

### Import/Export Configuration

#### Exporting Configuration
1. Click "📥 Export Configuration" to download your current settings
2. Choose "📋 Export Sample Configuration" for a template with example domains
3. Files are saved as JSON format for easy sharing and backup

#### Importing Configuration
1. Click "📁 Choose Configuration File" to select a JSON configuration file
2. The system will validate and import the settings
3. Existing configuration will be replaced

#### Reset to Defaults
Click "🔄 Reset to Defaults" to restore the original 6-domain sample configuration.

## Data Collection

### Understanding Data Collection
The dashboard displays data collected by PowerShell scripts that query your Active Directory domains. Data collection must be run separately from viewing the dashboard.

### Running Data Collection

#### Method 1: Batch File (Recommended)
1. Navigate to the `scripts` folder
2. Double-click `Run-Enhanced-AD-Dashboard.bat`
3. Follow the prompts in the command window
4. Wait for collection to complete

#### Method 2: PowerShell Direct
1. Open PowerShell as Administrator
2. Navigate to the scripts folder:
   ```powershell
   cd C:\AD-Dashboard\scripts
   ```
3. Run the collection script:
   ```powershell
   .\Enhanced-Multi-Domain-AD-Collector.ps1
   ```
4. Run the data embedding script:
   ```powershell
   .\Dashboard-Data-Embedder.ps1
   ```

### Collection Process
The data collection process includes:

1. **Configuration Loading**: Reads domain settings from configuration
2. **Domain Connectivity**: Tests connection to each enabled domain
3. **Data Gathering**: Collects users, computers, groups, and domain controllers
4. **Data Processing**: Aggregates and validates collected information
5. **File Generation**: Creates JSON data files for dashboard consumption
6. **Dashboard Integration**: Embeds data into HTML dashboard files

### Collection Output
After successful collection, you'll find:
- Individual domain data files in `data/individual/`
- Consolidated data file in `data/consolidated/`
- Updated dashboard files with embedded data
- Collection logs in `logs/` folder

### Scheduling Data Collection
For regular updates, consider scheduling the collection script:

#### Windows Task Scheduler
1. Open Task Scheduler
2. Create Basic Task
3. Set trigger (daily, weekly, etc.)
4. Set action to run the batch file
5. Configure additional settings as needed

#### PowerShell Scheduled Job
```powershell
# Create a scheduled job to run daily at 6 AM
Register-ScheduledJob -Name "AD-Dashboard-Collection" -ScriptBlock {
    Set-Location "C:\AD-Dashboard\scripts"
    .\Enhanced-Multi-Domain-AD-Collector.ps1
    .\Dashboard-Data-Embedder.ps1
} -Trigger (New-JobTrigger -Daily -At "6:00 AM")
```

## Using the Dashboard

### Opening the Dashboard
1. Navigate to the `dashboard` folder
2. Double-click `index.html` to open in your default browser
3. Or right-click and choose "Open with" to select a specific browser

### Navigation Basics

#### Domain Selection
- Use the dropdown in the header to filter data by domain
- "All Domains" shows aggregated data across all configured domains
- Individual domain selection shows data for that specific domain only

#### Tab Navigation
Click on any tab to switch views:
- Use mouse clicks or keyboard numbers (1-6)
- Each tab shows different aspects of your Active Directory data
- Content updates automatically when switching domains

### Overview Tab
The Overview tab provides a high-level summary:

#### Key Statistics
- **Collection Summary**: Number of domains, success/failure rates, collection duration
- **User Statistics**: Total, active, disabled, and locked user counts
- **Computer Statistics**: Total, active, and inactive computer counts
- **Security Overview**: Groups, domain controllers, and security metrics

#### Domain Status Cards
Each configured domain displays:
- Domain name and status (✅ Completed or ❌ Failed)
- FQDN and location information
- Contact information
- Key metrics (users, computers, groups, domain controllers)
- Connectivity status

### Users Tab
Detailed user account analysis:

#### User Statistics Grid
- **Total Users**: Complete count of user objects
- **Active Users**: Enabled user accounts
- **Disabled Users**: Disabled user accounts
- **Locked Users**: Locked user accounts

#### User Analysis
- Active user percentage calculation
- Disabled user percentage calculation
- Recommendations for account management

### Computers Tab
Computer inventory and activity monitoring:

#### Computer Statistics
- **Total Computers**: All computer objects
- **Active Computers**: Recently contacted computers
- **Inactive Computers**: Computers not seen recently

#### Computer Analysis
- Activity rate calculations
- Recommendations for computer management

### Security Tab
Security groups and domain infrastructure:

#### Security Metrics
- **Security Groups**: Security-enabled groups
- **Distribution Groups**: Mail-enabled distribution groups
- **Domain Controllers**: Domain controller count
- **Global Catalogs**: Global catalog server count

#### Security Analysis
- Security group distribution analysis
- Infrastructure health indicators

### Domains Tab
Individual domain management and detailed information:

#### Domain Cards
Each domain shows:
- Detailed configuration information
- Collection status and results
- Comprehensive metrics
- Connectivity status

#### Domain Management
- Click on domain cards to view detailed information
- Color-coded status indicators
- Expandable details for troubleshooting

### Reports Tab
Advanced reporting and analytics interface (detailed in next section).

## Generating Reports

### Accessing Reports
1. Click on the "📋 Reports" tab
2. The reporting interface provides multiple report types and export options

### Report Types

#### Executive Summary
High-level overview suitable for management:
- Key metrics across all domains
- Health indicators and status
- Domain overview table
- Recommendations for improvement

#### Detailed Analysis
Comprehensive technical analysis:
- In-depth user analysis
- Computer inventory details
- Security infrastructure review
- Statistical summaries

#### Security Report
Focused on security aspects:
- Security group analysis
- Domain controller status
- Account security metrics
- Security recommendations
- Compliance checklist

#### Compliance Report
Regulatory and policy compliance:
- Compliance status indicators
- Policy adherence metrics
- Audit trail information
- Recommended actions

#### Trend Analysis
Historical data analysis (when available):
- Growth trends over time
- Usage patterns
- Capacity planning data
- Performance metrics

### Report Configuration

#### Filters and Options
Before generating a report, configure:

**Report Type**: Select from the five available report types
**Domain Filter**: 
- "All Domains" for enterprise-wide reports
- Specific domain for focused analysis

**Date Range**: 
- "Current Data" for latest collection
- Historical ranges (when data available)

**Export Format**:
- **HTML Report**: Formatted for viewing and printing
- **CSV Data**: Tabular data for spreadsheet analysis
- **JSON Data**: Structured data for programmatic use
- **PDF Report**: Professional document format

### Generating Reports

#### Step-by-Step Process
1. **Select Report Type**: Choose the type of analysis needed
2. **Configure Filters**: Set domain scope and date range
3. **Choose Format**: Select output format
4. **Generate**: Click "📊 Generate Report"
5. **Review**: Examine the generated report
6. **Export**: Use "📥 Export Data" to download

#### Report Generation Time
- Simple reports: 1-2 seconds
- Complex reports with charts: 3-5 seconds
- Large datasets: Up to 10 seconds

### Understanding Report Content

#### Executive Summary Sections
- **Key Metrics**: Primary statistics and counts
- **Health Indicators**: Status and performance metrics
- **Domain Overview**: Per-domain summary table
- **Recommendations**: Actionable improvement suggestions

#### Detailed Analysis Sections
- **User Analysis**: Account status, distribution, trends
- **Computer Analysis**: Inventory, activity, lifecycle
- **Security Analysis**: Groups, permissions, infrastructure
- **Statistical Summary**: Aggregated data and calculations

#### Security Report Sections
- **Security Overview**: Current security posture
- **Security Recommendations**: Specific security improvements
- **Compliance Checklist**: Regulatory compliance status
- **Risk Assessment**: Identified risks and mitigation

## Data Export

### Export Formats

#### HTML Reports
- **Use Case**: Sharing with stakeholders, presentations
- **Features**: Formatted layout, embedded charts, professional appearance
- **Best For**: Executive summaries, compliance reports

#### CSV Data
- **Use Case**: Spreadsheet analysis, data manipulation
- **Features**: Tabular format, easy import to Excel
- **Best For**: Detailed analysis, custom calculations

#### JSON Data
- **Use Case**: Programmatic access, integration with other tools
- **Features**: Structured format, machine-readable
- **Best For**: API integration, custom applications

#### PDF Reports
- **Use Case**: Formal documentation, archival
- **Features**: Professional formatting, print-ready
- **Best For**: Official reports, compliance documentation

### Export Process

#### From Reports Tab
1. Configure report parameters
2. Generate the desired report
3. Click "📥 Export Data"
4. Choose export format
5. File downloads automatically

#### From Configuration Interface
1. Open `config.html`
2. Navigate to "📁 Import/Export" tab
3. Choose export type:
   - Current configuration
   - Sample configuration
4. File downloads as JSON

### Working with Exported Data

#### Excel Integration
For CSV exports:
1. Open Excel
2. Use "Data" > "From Text/CSV"
3. Select the downloaded CSV file
4. Configure import settings
5. Create charts and pivot tables as needed

#### PowerBI Integration
For JSON exports:
1. Open Power BI Desktop
2. Use "Get Data" > "JSON"
3. Select the downloaded JSON file
4. Transform data as needed
5. Create visualizations and dashboards

#### Custom Applications
For programmatic access:
```javascript
// Example: Loading JSON data
fetch('exported-data.json')
  .then(response => response.json())
  .then(data => {
    // Process the AD data
    console.log('Total Users:', data.aggregatedSummary.totalUsers);
  });
```

## Troubleshooting

### Common Issues and Solutions

#### Dashboard Shows "Loading..." or No Data

**Possible Causes:**
- Data collection hasn't been run
- Data collection failed
- Files are in wrong location
- Browser cache issues

**Solutions:**
1. Run the data collection script first
2. Check PowerShell output for errors
3. Verify all files are in correct folders
4. Clear browser cache and refresh
5. Check browser console for JavaScript errors

#### Configuration Won't Save

**Possible Causes:**
- Browser local storage disabled
- Insufficient permissions
- Browser security settings

**Solutions:**
1. Enable local storage in browser settings
2. Try a different browser
3. Run browser as administrator
4. Check for browser extensions blocking storage

#### Data Collection Fails

**Possible Causes:**
- Network connectivity issues
- Insufficient permissions
- Incorrect domain configuration
- PowerShell execution policy

**Solutions:**
1. Test network connectivity to domain controllers
2. Verify user has AD read permissions
3. Check domain FQDN configuration
4. Set PowerShell execution policy:
   ```powershell
   Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
   ```

#### Charts Not Displaying

**Possible Causes:**
- No internet connection for Chart.js
- Browser doesn't support Canvas
- JavaScript errors

**Solutions:**
1. Check internet connectivity
2. Use a modern browser
3. Check browser console for errors
4. Fallback simple charts will display automatically

#### Slow Performance

**Possible Causes:**
- Large datasets
- Slow network connections
- Insufficient system resources

**Solutions:**
1. Reduce data collection limits in global settings
2. Increase collection timeouts
3. Enable parallel collection
4. Close other applications

### Getting Additional Help

#### Self-Diagnosis Steps
1. **Check Prerequisites**: Verify all requirements are met
2. **Review Logs**: Examine PowerShell output and error messages
3. **Test Connectivity**: Use configuration interface to test domains
4. **Simplify**: Try with just one domain first
5. **Browser Console**: Check for JavaScript errors

#### Documentation Resources
- **README.md**: Overview and installation
- **TECHNICAL-GUIDE.md**: Advanced configuration and troubleshooting
- **Configuration Help**: Built-in help in config.html

#### Best Practices for Support
When seeking help:
1. Document exact error messages
2. Note steps to reproduce the issue
3. Include system information (OS, PowerShell version)
4. Describe your environment (number of domains, network setup)
5. Include relevant log excerpts

---

This user guide provides comprehensive instructions for using the Enhanced Multi-Domain Active Directory Dashboard. For technical implementation details, refer to the Technical Guide documentation.

