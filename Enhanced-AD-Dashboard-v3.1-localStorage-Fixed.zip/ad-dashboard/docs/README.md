# Enhanced Multi-Domain Active Directory Dashboard

## Version 3.1 - Fully Offline Edition

**🔒 COMPLETELY OFFLINE - NO EXTERNAL DEPENDENCIES**  
**✅ Works in locked-down environments without internet access**  
**📊 Pure HTML/CSS/JavaScript visualizations**

A comprehensive offline dashboard solution for monitoring and reporting on multiple Active Directory domains with advanced visualization, configuration management, and reporting capabilities.

## 🚀 Features

### Core Functionality
- **Multi-Domain Support**: Monitor up to 6 Active Directory domains simultaneously
- **Offline Operation**: Fully functional without internet connectivity after initial setup
- **Real-time Data**: Live dashboard updates with comprehensive AD metrics
- **Responsive Design**: Works seamlessly on desktop, tablet, and mobile devices

### Advanced Capabilities
- **Interactive Charts**: Dynamic visualizations using Chart.js with fallback support
- **Advanced Reporting**: Executive summaries, detailed analysis, security reports, and compliance reports
- **Data Export**: Multiple export formats (HTML, CSV, JSON, PDF)
- **Configuration Management**: Web-based domain configuration with validation and testing
- **Error Handling**: Comprehensive error handling and user notifications

### Dashboard Components
- **Overview Tab**: Multi-domain summary with key metrics and health indicators
- **Users Tab**: User account analysis with status distribution
- **Computers Tab**: Computer inventory and activity monitoring
- **Security Tab**: Security groups, domain controllers, and compliance metrics
- **Domains Tab**: Individual domain management and detailed information
- **Reports Tab**: Advanced reporting and analytics interface

## 📋 Requirements

### System Requirements
- **Operating System**: Windows 10/11 or Windows Server 2016+
- **PowerShell**: Version 5.0 or later
- **Active Directory Module**: Remote Server Administration Tools (RSAT)
- **Web Browser**: Modern browser (Chrome, Firefox, Edge, Safari)
- **Network**: Connectivity to target Active Directory domains

### Permissions Required
- **Domain Access**: Read permissions to Active Directory
- **PowerShell Execution**: Ability to run PowerShell scripts
- **File System**: Read/write access to dashboard directory

### Optional Components
- **Chart.js**: Automatically loaded from CDN for enhanced visualizations
- **PDF Export**: Browser support for PDF generation

## 📦 Installation

### Quick Start
1. **Download**: Extract all files to a local directory (e.g., `C:\AD-Dashboard`)
2. **Configure**: Run the configuration interface to set up your domains
3. **Collect Data**: Execute the PowerShell data collection script
4. **View Dashboard**: Open the HTML dashboard in your web browser

### Detailed Installation Steps

#### Step 1: Prepare Environment
```powershell
# Ensure PowerShell execution policy allows script execution
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser

# Verify Active Directory module is available
Import-Module ActiveDirectory
```

#### Step 2: Extract Files
Extract the dashboard package to your preferred location:
```
C:\AD-Dashboard\
├── dashboard/
│   ├── index.html              # Main dashboard
│   ├── config.html             # Configuration interface
│   ├── script.js               # Core dashboard functionality
│   ├── config-manager.js       # Configuration management
│   └── visualization.js        # Charts and reporting
├── scripts/
│   ├── Enhanced-Multi-Domain-AD-Collector.ps1
│   ├── Dashboard-Data-Embedder.ps1
│   └── Run-Enhanced-AD-Dashboard.bat
├── data/
│   └── consolidated/           # Generated data files
├── docs/
│   ├── README.md              # This file
│   ├── USER-GUIDE.md          # User guide
│   └── TECHNICAL-GUIDE.md     # Technical documentation
└── assets/
    ├── css/                   # Additional stylesheets
    ├── js/                    # Additional scripts
    └── images/                # Dashboard assets
```

#### Step 3: Configure Domains
1. Open `dashboard/config.html` in your web browser
2. Configure your Active Directory domains:
   - Domain ID (unique identifier)
   - Domain Name (display name)
   - FQDN (fully qualified domain name)
   - Location and contact information
   - Priority and color coding
3. Test connectivity to each domain
4. Save configuration

#### Step 4: Collect Data
Run the data collection script:
```batch
# Navigate to scripts directory
cd C:\AD-Dashboard\scripts

# Run the enhanced collection script
.\Run-Enhanced-AD-Dashboard.bat
```

Or run PowerShell directly:
```powershell
# Execute the main collection script
.\Enhanced-Multi-Domain-AD-Collector.ps1

# Embed data into dashboard
.\Dashboard-Data-Embedder.ps1
```

#### Step 5: Access Dashboard
1. Open `dashboard/index.html` in your web browser
2. Navigate through different tabs to explore your AD data
3. Use the domain selector to filter by specific domains
4. Generate reports and export data as needed

## ⚙️ Configuration

### Domain Configuration
Each domain requires the following information:

| Field | Description | Required | Example |
|-------|-------------|----------|---------|
| Domain ID | Unique identifier | Yes | `corp-hq` |
| Domain Name | Display name | Yes | `Corporate Headquarters` |
| FQDN | Fully qualified domain name | Yes | `corp.company.com` |
| Description | Brief description | No | `Main corporate domain` |
| Location | Physical/logical location | No | `New York, NY` |
| Contact | Administrator email | No | `admin@corp.company.com` |
| Priority | Collection order (1-10) | Yes | `1` |
| Color | Visual identifier | Yes | `#3498db` |

### Global Settings
Configure collection and dashboard behavior:

#### Collection Settings
- **Timeout**: Maximum collection time per domain (60-3600 seconds)
- **Retry Attempts**: Number of retry attempts for failed collections (1-10)
- **Parallel Collection**: Enable simultaneous domain collection
- **Data Limits**: Maximum objects to collect per domain

#### Dashboard Settings
- **Title**: Custom dashboard title
- **Refresh Interval**: Auto-refresh interval (5-1440 minutes)
- **Real-time Updates**: Enable live data updates
- **Default View**: Initial tab to display

### Authentication
The dashboard supports multiple authentication methods:
- **Current User**: Use current Windows credentials (default)
- **Alternate Credentials**: Specify username and domain
- **Service Account**: Use dedicated service account

## 🔧 Usage

### Basic Operations

#### Viewing Data
1. **Overview**: Get a high-level summary of all domains
2. **Domain Selection**: Use the dropdown to filter by specific domain
3. **Tab Navigation**: Switch between different data views
4. **Refresh**: Click refresh to update with latest data

#### Generating Reports
1. Navigate to the **Reports** tab
2. Select report type:
   - Executive Summary
   - Detailed Analysis
   - Security Report
   - Compliance Report
   - Trend Analysis
3. Choose domain filter and date range
4. Select export format (HTML, CSV, JSON, PDF)
5. Click "Generate Report"

#### Exporting Data
- **CSV**: Tabular data for spreadsheet analysis
- **JSON**: Structured data for programmatic use
- **HTML**: Formatted report for sharing
- **PDF**: Professional report format

### Advanced Features

#### Configuration Management
- **Import/Export**: Backup and restore configurations
- **Validation**: Automatic validation of domain settings
- **Connectivity Testing**: Verify domain accessibility
- **Bulk Operations**: Configure multiple domains efficiently

#### Data Visualization
- **Interactive Charts**: Click and hover for detailed information
- **Responsive Design**: Automatic layout adjustment
- **Fallback Support**: Simple charts when Chart.js unavailable
- **Color Coding**: Visual domain identification

#### Error Handling
- **Automatic Retry**: Failed collections automatically retry
- **Error Reporting**: Detailed error messages and logging
- **Graceful Degradation**: Partial data display when some domains fail
- **User Notifications**: Real-time status updates

## 🛠️ Troubleshooting

### Common Issues

#### Data Collection Fails
**Symptoms**: No data appears in dashboard, error messages in PowerShell
**Solutions**:
1. Verify network connectivity to domain controllers
2. Check Active Directory module installation
3. Confirm user permissions for AD access
4. Review PowerShell execution policy
5. Check domain FQDN configuration

#### Dashboard Not Loading
**Symptoms**: Blank page, JavaScript errors in browser console
**Solutions**:
1. Ensure all files are in correct locations
2. Check browser JavaScript is enabled
3. Verify file permissions allow reading
4. Try different web browser
5. Check for popup blockers

#### Charts Not Displaying
**Symptoms**: Simple text displays instead of charts
**Solutions**:
1. Verify internet connectivity for Chart.js CDN
2. Check browser JavaScript console for errors
3. Ensure modern browser with Canvas support
4. Try refreshing the page
5. Use fallback simple charts if needed

#### Configuration Issues
**Symptoms**: Cannot save configuration, validation errors
**Solutions**:
1. Check browser local storage is enabled
2. Verify domain FQDN format is correct
3. Ensure unique domain IDs
4. Validate email addresses format
5. Check for special characters in names

### Performance Optimization

#### Large Environments
- Increase collection timeouts for large domains
- Enable parallel collection for faster processing
- Reduce data limits if memory constraints exist
- Schedule collections during off-peak hours

#### Network Considerations
- Use domain controllers in same network segment
- Configure appropriate retry attempts for unreliable connections
- Consider VPN connectivity for remote domains
- Monitor network bandwidth during collection

## 📊 Data Collection Details

### Collected Information

#### User Objects
- Total user count
- Active/disabled/locked status
- Account properties and attributes
- Group memberships
- Last logon information

#### Computer Objects
- Total computer count
- Active/inactive status
- Operating system information
- Last contact timestamps
- Computer attributes

#### Security Groups
- Security and distribution groups
- Group memberships
- Nested group relationships
- Group properties

#### Domain Controllers
- Domain controller inventory
- Global catalog servers
- FSMO role holders
- Replication status

### Data Processing
1. **Collection**: PowerShell scripts query each domain
2. **Aggregation**: Data consolidated across all domains
3. **Validation**: Data integrity checks and error handling
4. **Storage**: JSON format for dashboard consumption
5. **Embedding**: Data integrated into HTML dashboard

### Data Security
- **Local Storage**: All data remains on local system
- **No Cloud**: No data transmitted to external services
- **Encryption**: Consider encrypting data files if required
- **Access Control**: Secure dashboard directory appropriately

## 🔒 Security Considerations

### Access Control
- Limit dashboard access to authorized personnel
- Use least-privilege accounts for data collection
- Secure PowerShell script execution
- Protect configuration files

### Data Protection
- Consider encrypting sensitive data files
- Implement secure file permissions
- Regular backup of configuration and data
- Monitor access to dashboard files

### Network Security
- Use secure connections to domain controllers
- Consider VPN for remote domain access
- Monitor network traffic during collection
- Implement appropriate firewall rules

## 📈 Maintenance

### Regular Tasks
- **Weekly**: Review dashboard data for anomalies
- **Monthly**: Update domain configurations as needed
- **Quarterly**: Review and update documentation
- **Annually**: Audit access permissions and security

### Updates and Upgrades
- Monitor for new dashboard versions
- Test updates in non-production environment
- Backup configuration before upgrades
- Review change logs for new features

### Monitoring
- Set up automated data collection schedules
- Monitor collection success rates
- Review error logs regularly
- Track dashboard usage and performance

## 🆘 Support

### Documentation
- **README.md**: This overview document
- **USER-GUIDE.md**: Detailed user instructions
- **TECHNICAL-GUIDE.md**: Technical implementation details
- **CHANGELOG.md**: Version history and updates

### Self-Help Resources
1. Check troubleshooting section above
2. Review browser console for JavaScript errors
3. Examine PowerShell error messages
4. Verify configuration settings
5. Test with minimal domain set

### Getting Help
For additional support:
1. Review all documentation thoroughly
2. Check system requirements and prerequisites
3. Verify network connectivity and permissions
4. Test with single domain first
5. Document specific error messages and steps to reproduce

## 📄 License

This Enhanced Multi-Domain Active Directory Dashboard is provided as-is for educational and internal use. Please ensure compliance with your organization's policies and Microsoft licensing requirements for Active Directory access.

## 🔄 Version History

### Version 3.0 (Current)
- Enhanced multi-domain support
- Advanced visualization with Chart.js
- Comprehensive reporting system
- Web-based configuration management
- Improved error handling and user experience
- Responsive design for all devices
- Data export capabilities

### Version 2.0
- Multi-domain collection support
- Basic dashboard interface
- PowerShell automation scripts

### Version 1.0
- Single domain support
- Basic data collection
- Simple HTML dashboard

---

**Enhanced Multi-Domain Active Directory Dashboard v3.0**  
*Enterprise-grade Active Directory monitoring and reporting solution*

