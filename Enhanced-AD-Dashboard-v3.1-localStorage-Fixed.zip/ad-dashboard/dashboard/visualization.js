// Enhanced Offline Data Visualization and Reporting Module
// Version: 3.1 - Fully Offline Edition
// Pure CSS/HTML charts and reporting for Multi-Domain AD Dashboard
// NO EXTERNAL DEPENDENCIES - Works in completely locked-down environments

// Visualization Configuration
const VISUALIZATION_CONFIG = {
    charts: {
        defaultColors: [
            '#3498db', '#9b59b6', '#e67e22', '#1abc9c', '#e74c3c', '#f1c40f',
            '#2ecc71', '#34495e', '#f39c12', '#d35400', '#8e44ad', '#27ae60'
        ],
        animations: {
            duration: 1000,
            easing: 'ease-in-out'
        }
    },
    reports: {
        maxItemsPerPage: 50,
        exportFormats: ['csv', 'json', 'html'],
        defaultSortField: 'name',
        defaultSortOrder: 'asc'
    }
};

// Offline Data Visualization Manager
const OfflineVisualizationManager = {
    charts: new Map(),
    
    // Initialize visualization components
    initialize: function() {
        console.log('📊 Initializing Offline Data Visualization Manager...');
        
        try {
            // Initialize chart containers
            this.initializeChartContainers();
            
            // Set up event listeners
            this.setupEventListeners();
            
            console.log('✅ Offline Data Visualization Manager initialized');
            
        } catch (error) {
            console.error('❌ Error initializing visualization manager:', error);
        }
    },
    
    // Initialize chart containers
    initializeChartContainers: function() {
        // Add chart containers to existing tabs if they don't exist
        this.ensureChartContainers();
    },
    
    // Ensure chart containers exist in tabs
    ensureChartContainers: function() {
        const tabContents = {
            'overview': this.createOverviewCharts,
            'users': this.createUserCharts,
            'computers': this.createComputerCharts,
            'security': this.createSecurityCharts,
            'domains': this.createDomainCharts,
            'reports': this.createReportsInterface
        };
        
        Object.keys(tabContents).forEach(tabName => {
            const tabElement = document.getElementById(`${tabName}-content`);
            if (tabElement) {
                // Add charts section if it doesn't exist
                let chartsSection = tabElement.querySelector('.charts-section');
                if (!chartsSection) {
                    chartsSection = document.createElement('div');
                    chartsSection.className = 'charts-section';
                    tabElement.appendChild(chartsSection);
                }
            }
        });
    },
    
    // Set up event listeners
    setupEventListeners: function() {
        // Listen for tab changes to update charts
        document.addEventListener('tabChanged', (e) => {
            this.updateChartsForTab(e.detail.tabName);
        });
        
        // Listen for domain changes to update charts
        document.addEventListener('domainChanged', (e) => {
            this.updateAllCharts();
        });
        
        // Window resize handler for responsive charts
        window.addEventListener('resize', () => {
            this.resizeAllCharts();
        });
    },
    
    // Create overview charts using pure CSS/HTML
    createOverviewCharts: function(container, data) {
        if (!data || !data.summary) return;
        
        const chartsHTML = `
            <div class="offline-charts-grid">
                <div class="offline-chart-container">
                    <h4>📊 Domain Distribution</h4>
                    <div class="offline-chart" id="domainDistributionChart"></div>
                </div>
                <div class="offline-chart-container">
                    <h4>👥 User Status Distribution</h4>
                    <div class="offline-chart" id="userStatusChart"></div>
                </div>
                <div class="offline-chart-container">
                    <h4>💻 Computer Activity</h4>
                    <div class="offline-chart" id="computerActivityChart"></div>
                </div>
                <div class="offline-chart-container">
                    <h4>📈 Key Metrics Overview</h4>
                    <div class="offline-chart" id="metricsChart"></div>
                </div>
            </div>
        `;
        
        container.innerHTML = chartsHTML;
        
        // Create individual charts
        this.createOfflineDomainChart(data);
        this.createOfflineUserChart(data);
        this.createOfflineComputerChart(data);
        this.createOfflineMetricsChart(data);
    },
    
    // Create domain distribution chart using CSS
    createOfflineDomainChart: function(data) {
        const container = document.getElementById('domainDistributionChart');
        if (!container) return;
        
        const domainData = this.prepareDomainData(data);
        const total = domainData.values.reduce((a, b) => a + b, 0);
        
        let chartHTML = '<div class="css-pie-chart">';
        let currentAngle = 0;
        
        domainData.labels.forEach((label, index) => {
            const value = domainData.values[index];
            const percentage = total > 0 ? (value / total) * 100 : 0;
            const angle = (value / total) * 360;
            
            chartHTML += `
                <div class="pie-slice" style="
                    --start-angle: ${currentAngle}deg;
                    --end-angle: ${currentAngle + angle}deg;
                    --slice-color: ${VISUALIZATION_CONFIG.charts.defaultColors[index % VISUALIZATION_CONFIG.charts.defaultColors.length]};
                "></div>
            `;
            
            currentAngle += angle;
        });
        
        chartHTML += '</div>';
        
        // Add legend
        chartHTML += '<div class="chart-legend">';
        domainData.labels.forEach((label, index) => {
            const value = domainData.values[index];
            const percentage = total > 0 ? ((value / total) * 100).toFixed(1) : 0;
            chartHTML += `
                <div class="legend-item">
                    <span class="legend-color" style="background-color: ${VISUALIZATION_CONFIG.charts.defaultColors[index % VISUALIZATION_CONFIG.charts.defaultColors.length]};"></span>
                    <span class="legend-label">${label}: ${value} (${percentage}%)</span>
                </div>
            `;
        });
        chartHTML += '</div>';
        
        container.innerHTML = chartHTML;
    },
    
    // Create user status chart using CSS bars
    createOfflineUserChart: function(data) {
        const container = document.getElementById('userStatusChart');
        if (!container) return;
        
        const userData = this.prepareUserStatusData(data);
        const maxValue = Math.max(...userData.values);
        
        let chartHTML = '<div class="css-bar-chart">';
        
        userData.labels.forEach((label, index) => {
            const value = userData.values[index];
            const height = maxValue > 0 ? (value / maxValue) * 100 : 0;
            const colors = ['#27ae60', '#e74c3c', '#f39c12', '#3498db'];
            
            chartHTML += `
                <div class="bar-item">
                    <div class="bar-container">
                        <div class="bar-fill" style="
                            height: ${height}%;
                            background-color: ${colors[index % colors.length]};
                            animation: barGrow 1s ease-out;
                        "></div>
                    </div>
                    <div class="bar-label">${label}</div>
                    <div class="bar-value">${value}</div>
                </div>
            `;
        });
        
        chartHTML += '</div>';
        container.innerHTML = chartHTML;
    },
    
    // Create computer activity chart using CSS
    createOfflineComputerChart: function(data) {
        const container = document.getElementById('computerActivityChart');
        if (!container) return;
        
        const computerData = this.prepareComputerData(data);
        const total = computerData.active + computerData.inactive;
        const activePercentage = total > 0 ? (computerData.active / total) * 100 : 0;
        const inactivePercentage = total > 0 ? (computerData.inactive / total) * 100 : 0;
        
        const chartHTML = `
            <div class="css-donut-chart">
                <div class="donut-segment active" style="
                    --percentage: ${activePercentage};
                    --color: #27ae60;
                "></div>
                <div class="donut-segment inactive" style="
                    --percentage: ${inactivePercentage};
                    --color: #e74c3c;
                "></div>
                <div class="donut-center">
                    <div class="donut-total">${total}</div>
                    <div class="donut-label">Computers</div>
                </div>
            </div>
            <div class="chart-legend">
                <div class="legend-item">
                    <span class="legend-color" style="background-color: #27ae60;"></span>
                    <span class="legend-label">Active: ${computerData.active} (${activePercentage.toFixed(1)}%)</span>
                </div>
                <div class="legend-item">
                    <span class="legend-color" style="background-color: #e74c3c;"></span>
                    <span class="legend-label">Inactive: ${computerData.inactive} (${inactivePercentage.toFixed(1)}%)</span>
                </div>
            </div>
        `;
        
        container.innerHTML = chartHTML;
    },
    
    // Create metrics overview chart
    createOfflineMetricsChart: function(data) {
        const container = document.getElementById('metricsChart');
        if (!container) return;
        
        const summary = data.summary || {};
        
        const chartHTML = `
            <div class="metrics-grid">
                <div class="metric-card">
                    <div class="metric-icon">👥</div>
                    <div class="metric-value">${(summary.totalUsers || 0).toLocaleString()}</div>
                    <div class="metric-label">Total Users</div>
                    <div class="metric-bar">
                        <div class="metric-fill" style="width: 100%; background: #3498db;"></div>
                    </div>
                </div>
                <div class="metric-card">
                    <div class="metric-icon">✅</div>
                    <div class="metric-value">${(summary.activeUsers || 0).toLocaleString()}</div>
                    <div class="metric-label">Active Users</div>
                    <div class="metric-bar">
                        <div class="metric-fill" style="width: ${this.calculatePercentage(summary.activeUsers, summary.totalUsers)}%; background: #27ae60;"></div>
                    </div>
                </div>
                <div class="metric-card">
                    <div class="metric-icon">💻</div>
                    <div class="metric-value">${(summary.totalComputers || 0).toLocaleString()}</div>
                    <div class="metric-label">Total Computers</div>
                    <div class="metric-bar">
                        <div class="metric-fill" style="width: 100%; background: #9b59b6;"></div>
                    </div>
                </div>
                <div class="metric-card">
                    <div class="metric-icon">🔒</div>
                    <div class="metric-value">${(summary.securityGroups || 0).toLocaleString()}</div>
                    <div class="metric-label">Security Groups</div>
                    <div class="metric-bar">
                        <div class="metric-fill" style="width: 100%; background: #e67e22;"></div>
                    </div>
                </div>
            </div>
        `;
        
        container.innerHTML = chartHTML;
    },
    
    // Prepare domain data for charts
    prepareDomainData: function(data) {
        if (!data.domainData) {
            return { labels: ['No Data'], values: [1] };
        }
        
        const domains = Object.values(data.domainData);
        const labels = domains.map(d => d.info?.name || 'Unknown');
        const values = domains.map(d => d.summary?.totalUsers || 0);
        
        return { labels, values };
    },
    
    // Prepare user status data
    prepareUserStatusData: function(data) {
        const summary = data.summary || {};
        
        return {
            labels: ['Active', 'Disabled', 'Locked'],
            values: [
                summary.activeUsers || 0,
                summary.disabledUsers || 0,
                summary.lockedUsers || 0
            ]
        };
    },
    
    // Prepare computer data
    prepareComputerData: function(data) {
        const summary = data.summary || {};
        
        return {
            active: summary.activeComputers || 0,
            inactive: summary.inactiveComputers || 0
        };
    },
    
    // Calculate percentage helper
    calculatePercentage: function(part, total) {
        if (!total || total === 0) return 0;
        return Math.round((part / total) * 100);
    },
    
    // Update charts for specific tab
    updateChartsForTab: function(tabName) {
        console.log('📊 Updating offline charts for tab:', tabName);
        
        if (!dashboardState.consolidatedData) return;
        
        const data = DataManager.getDomainData(dashboardState.currentDomain);
        if (!data) return;
        
        switch (tabName) {
            case 'overview':
                this.updateOverviewCharts(data);
                break;
            case 'users':
                this.updateUserCharts(data);
                break;
            case 'computers':
                this.updateComputerCharts(data);
                break;
            case 'security':
                this.updateSecurityCharts(data);
                break;
            case 'domains':
                this.updateDomainCharts(data);
                break;
            case 'reports':
                this.updateReportsInterface(data);
                break;
        }
    },
    
    // Update overview charts
    updateOverviewCharts: function(data) {
        const container = document.querySelector('#overview-content .charts-section');
        if (container) {
            this.createOverviewCharts(container, data);
        }
    },
    
    // Update all charts
    updateAllCharts: function() {
        console.log('📊 Updating all offline charts');
        
        // Re-create charts for current tab
        this.updateChartsForTab(dashboardState.currentTab);
    },
    
    // Resize all charts (for responsive design)
    resizeAllCharts: function() {
        // CSS charts automatically resize, but we can trigger animations
        const charts = document.querySelectorAll('.offline-chart');
        charts.forEach(chart => {
            chart.style.animation = 'none';
            chart.offsetHeight; // Trigger reflow
            chart.style.animation = null;
        });
    }
};

// Enhanced Offline Reporting Manager
const OfflineReportingManager = {
    currentFilters: {},
    currentSort: { field: 'name', order: 'asc' },
    currentPage: 1,
    
    // Initialize reporting interface
    initialize: function() {
        console.log('📋 Initializing Offline Reporting Manager...');
        
        try {
            this.setupReportingInterface();
            this.setupEventListeners();
            
            console.log('✅ Offline Reporting Manager initialized');
            
        } catch (error) {
            console.error('❌ Error initializing reporting manager:', error);
        }
    },
    
    // Set up reporting interface
    setupReportingInterface: function() {
        const reportsTab = document.getElementById('reports-tab');
        if (!reportsTab) return;
        
        const reportingHTML = `
            <div class="offline-reporting-interface">
                <div class="reporting-header">
                    <h3>📋 Advanced Reports and Analytics</h3>
                    <div class="reporting-actions">
                        <button class="btn btn-primary" onclick="OfflineReportingManager.generateReport()">
                            <span>📊</span>
                            Generate Report
                        </button>
                        <button class="btn btn-secondary" onclick="OfflineReportingManager.exportData()">
                            <span>📥</span>
                            Export Data
                        </button>
                    </div>
                </div>
                
                <div class="reporting-filters">
                    <div class="filter-group">
                        <label>Report Type:</label>
                        <select id="reportType" class="form-select">
                            <option value="summary">Executive Summary</option>
                            <option value="detailed">Detailed Analysis</option>
                            <option value="security">Security Report</option>
                            <option value="compliance">Compliance Report</option>
                        </select>
                    </div>
                    
                    <div class="filter-group">
                        <label>Domain Filter:</label>
                        <select id="domainFilter" class="form-select">
                            <option value="all">All Domains</option>
                        </select>
                    </div>
                    
                    <div class="filter-group">
                        <label>Format:</label>
                        <select id="exportFormat" class="form-select">
                            <option value="html">HTML Report</option>
                            <option value="csv">CSV Data</option>
                            <option value="json">JSON Data</option>
                        </select>
                    </div>
                </div>
                
                <div class="reporting-content" id="reportingContent">
                    <div class="report-placeholder">
                        <p>Select report parameters and click "Generate Report" to create a comprehensive analysis.</p>
                        <p><strong>Note:</strong> This version works completely offline without any external dependencies.</p>
                    </div>
                </div>
            </div>
        `;
        
        reportsTab.innerHTML = reportingHTML;
        
        // Populate domain filter
        this.populateDomainFilter();
    },
    
    // Set up event listeners
    setupEventListeners: function() {
        // Filter change handlers
        ['reportType', 'domainFilter', 'exportFormat'].forEach(id => {
            const element = document.getElementById(id);
            if (element) {
                element.addEventListener('change', () => {
                    this.updateFilters();
                });
            }
        });
    },
    
    // Populate domain filter dropdown
    populateDomainFilter: function() {
        const domainFilter = document.getElementById('domainFilter');
        if (!domainFilter || !dashboardState.consolidatedData) return;
        
        // Clear existing options except "All Domains"
        domainFilter.innerHTML = '<option value="all">All Domains</option>';
        
        // Add domain options
        const domains = DataManager.getAvailableDomains();
        domains.forEach(domain => {
            const option = document.createElement('option');
            option.value = domain.id;
            option.textContent = domain.name;
            domainFilter.appendChild(option);
        });
    },
    
    // Update filters
    updateFilters: function() {
        this.currentFilters = {
            reportType: document.getElementById('reportType')?.value || 'summary',
            domain: document.getElementById('domainFilter')?.value || 'all',
            format: document.getElementById('exportFormat')?.value || 'html'
        };
        
        console.log('🔍 Updated report filters:', this.currentFilters);
    },
    
    // Generate report
    generateReport: function() {
        console.log('📊 Generating offline report with filters:', this.currentFilters);
        
        this.updateFilters();
        
        const reportContent = document.getElementById('reportingContent');
        if (!reportContent) return;
        
        // Show loading state
        reportContent.innerHTML = '<div class="loading-state">📊 Generating offline report...</div>';
        
        // Generate report
        setTimeout(() => {
            const report = this.createOfflineReport(this.currentFilters);
            reportContent.innerHTML = report;
        }, 1000);
    },
    
    // Create offline report
    createOfflineReport: function(filters) {
        const data = filters.domain === 'all' 
            ? dashboardState.consolidatedData 
            : { domainData: { [filters.domain]: DataManager.getDomainData(filters.domain) } };
        
        if (!data) {
            return '<div class="error-state">❌ No data available for report generation</div>';
        }
        
        switch (filters.reportType) {
            case 'summary':
                return this.createOfflineExecutiveSummary(data);
            case 'detailed':
                return this.createOfflineDetailedAnalysis(data);
            case 'security':
                return this.createOfflineSecurityReport(data);
            case 'compliance':
                return this.createOfflineComplianceReport(data);
            default:
                return this.createOfflineExecutiveSummary(data);
        }
    },
    
    // Create executive summary report
    createOfflineExecutiveSummary: function(data) {
        const summary = data.aggregatedSummary || {};
        const metadata = data.metadata || {};
        
        return `
            <div class="offline-report-document">
                <div class="report-header">
                    <h2>📊 Executive Summary Report</h2>
                    <div class="report-meta">
                        <p><strong>Generated:</strong> ${new Date().toLocaleString()}</p>
                        <p><strong>Environment:</strong> Completely Offline (No External Dependencies)</p>
                        <p><strong>Scope:</strong> ${this.currentFilters.domain === 'all' ? 'All Domains' : 'Single Domain'}</p>
                    </div>
                </div>
                
                <div class="report-section">
                    <h3>🎯 Key Metrics</h3>
                    <div class="offline-metrics-grid">
                        <div class="metric-card">
                            <div class="metric-icon">👥</div>
                            <div class="metric-value">${(summary.totalUsers || 0).toLocaleString()}</div>
                            <div class="metric-label">Total Users</div>
                        </div>
                        <div class="metric-card">
                            <div class="metric-icon">✅</div>
                            <div class="metric-value">${(summary.activeUsers || 0).toLocaleString()}</div>
                            <div class="metric-label">Active Users</div>
                        </div>
                        <div class="metric-card">
                            <div class="metric-icon">💻</div>
                            <div class="metric-value">${(summary.totalComputers || 0).toLocaleString()}</div>
                            <div class="metric-label">Total Computers</div>
                        </div>
                        <div class="metric-card">
                            <div class="metric-icon">🔒</div>
                            <div class="metric-value">${(summary.securityGroups || 0).toLocaleString()}</div>
                            <div class="metric-label">Security Groups</div>
                        </div>
                    </div>
                </div>
                
                <div class="report-section">
                    <h3>📈 Health Indicators</h3>
                    <div class="health-indicators">
                        <div class="indicator ${this.getHealthStatus(summary.activeUsers, summary.totalUsers)}">
                            <span class="indicator-label">User Activity Rate:</span>
                            <span class="indicator-value">${this.calculatePercentage(summary.activeUsers, summary.totalUsers)}%</span>
                        </div>
                        <div class="indicator ${this.getHealthStatus(summary.activeComputers, summary.totalComputers)}">
                            <span class="indicator-label">Computer Activity Rate:</span>
                            <span class="indicator-value">${this.calculatePercentage(summary.activeComputers, summary.totalComputers)}%</span>
                        </div>
                    </div>
                </div>
                
                <div class="report-section">
                    <h3>🏢 Domain Overview</h3>
                    <div class="domain-summary">
                        ${this.createOfflineDomainTable(data)}
                    </div>
                </div>
                
                <div class="report-section">
                    <h3>💡 Recommendations</h3>
                    <div class="recommendations">
                        ${this.generateOfflineRecommendations(summary)}
                    </div>
                </div>
            </div>
        `;
    },
    
    // Helper functions
    calculatePercentage: function(part, total) {
        if (!total || total === 0) return 0;
        return Math.round((part / total) * 100);
    },
    
    getHealthStatus: function(active, total) {
        const percentage = this.calculatePercentage(active, total);
        if (percentage >= 80) return 'good';
        if (percentage >= 60) return 'warning';
        return 'critical';
    },
    
    createOfflineDomainTable: function(data) {
        if (!data.domainData) return '<p>No domain data available</p>';
        
        const domains = Object.values(data.domainData);
        let tableHTML = `
            <table class="offline-report-table">
                <thead>
                    <tr>
                        <th>Domain</th>
                        <th>Status</th>
                        <th>Users</th>
                        <th>Computers</th>
                        <th>Groups</th>
                    </tr>
                </thead>
                <tbody>
        `;
        
        domains.forEach(domain => {
            if (domain.info) {
                tableHTML += `
                    <tr>
                        <td>${domain.info.name}</td>
                        <td><span class="status ${domain.status.toLowerCase()}">${domain.status}</span></td>
                        <td>${(domain.summary?.totalUsers || 0).toLocaleString()}</td>
                        <td>${(domain.summary?.totalComputers || 0).toLocaleString()}</td>
                        <td>${(domain.summary?.totalGroups || 0).toLocaleString()}</td>
                    </tr>
                `;
            }
        });
        
        tableHTML += '</tbody></table>';
        return tableHTML;
    },
    
    generateOfflineRecommendations: function(summary) {
        const recommendations = [];
        
        const userActivityRate = this.calculatePercentage(summary.activeUsers, summary.totalUsers);
        const computerActivityRate = this.calculatePercentage(summary.activeComputers, summary.totalComputers);
        
        if (userActivityRate < 80) {
            recommendations.push('Consider reviewing inactive user accounts for potential cleanup');
        }
        
        if (computerActivityRate < 70) {
            recommendations.push('Review inactive computer accounts and consider removal of stale objects');
        }
        
        if (summary.lockedUsers > 0) {
            recommendations.push('Investigate locked user accounts and implement account unlock procedures');
        }
        
        if (recommendations.length === 0) {
            recommendations.push('Infrastructure appears healthy - continue regular monitoring');
        }
        
        return recommendations.map(rec => `<div class="recommendation-item">💡 ${rec}</div>`).join('');
    },
    
    // Export data functionality (offline only)
    exportData: function() {
        this.updateFilters();
        
        const format = this.currentFilters.format;
        const data = this.prepareExportData();
        
        switch (format) {
            case 'csv':
                this.exportCSV(data);
                break;
            case 'json':
                this.exportJSON(data);
                break;
            case 'html':
            default:
                this.exportHTML(data);
                break;
        }
    },
    
    // Prepare data for export
    prepareExportData: function() {
        const domainId = this.currentFilters.domain;
        
        if (domainId === 'all') {
            return dashboardState.consolidatedData;
        } else {
            return DataManager.getDomainData(domainId);
        }
    },
    
    // Export as CSV
    exportCSV: function(data) {
        let csv = 'Domain,Users,Active Users,Computers,Active Computers,Groups\n';
        
        if (data.domainData) {
            Object.values(data.domainData).forEach(domain => {
                if (domain.info && domain.summary) {
                    csv += `"${domain.info.name}",${domain.summary.totalUsers || 0},${domain.summary.activeUsers || 0},${domain.summary.totalComputers || 0},${domain.summary.activeComputers || 0},${domain.summary.totalGroups || 0}\n`;
                }
            });
        }
        
        this.downloadFile(csv, 'ad-dashboard-data.csv', 'text/csv');
    },
    
    // Export as JSON
    exportJSON: function(data) {
        const jsonData = JSON.stringify(data, null, 2);
        this.downloadFile(jsonData, 'ad-dashboard-data.json', 'application/json');
    },
    
    // Export as HTML
    exportHTML: function(data) {
        const report = this.createOfflineReport(this.currentFilters);
        const htmlDocument = `
            <!DOCTYPE html>
            <html>
            <head>
                <title>AD Dashboard Report - Offline Version</title>
                <style>
                    body { font-family: Arial, sans-serif; margin: 20px; }
                    .offline-report-document { max-width: 800px; margin: 0 auto; }
                    .report-header { border-bottom: 2px solid #3498db; padding-bottom: 20px; margin-bottom: 30px; }
                    .report-section { margin-bottom: 30px; }
                    .offline-report-table { width: 100%; border-collapse: collapse; }
                    .offline-report-table th, .offline-report-table td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                    .offline-report-table th { background-color: #f2f2f2; }
                    .offline-metrics-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; }
                    .metric-card { background: #f8f9fa; padding: 15px; border-radius: 5px; text-align: center; }
                    .status.completed { color: #27ae60; }
                    .status.failed { color: #e74c3c; }
                </style>
            </head>
            <body>
                ${report}
                <footer style="margin-top: 40px; padding-top: 20px; border-top: 1px solid #ddd; text-align: center; color: #666;">
                    <p>Generated by Enhanced Multi-Domain AD Dashboard v3.1 - Fully Offline Edition</p>
                </footer>
            </body>
            </html>
        `;
        
        this.downloadFile(htmlDocument, 'ad-dashboard-report-offline.html', 'text/html');
    },
    
    // Download file helper
    downloadFile: function(content, filename, mimeType) {
        const blob = new Blob([content], { type: mimeType });
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        if (typeof NotificationManager !== 'undefined') {
            NotificationManager.show(`Report exported as ${filename}`, 'success');
        }
    }
};

// Initialize offline visualization and reporting when dashboard loads
document.addEventListener('DOMContentLoaded', function() {
    // Wait for main dashboard to initialize
    setTimeout(() => {
        OfflineVisualizationManager.initialize();
        OfflineReportingManager.initialize();
    }, 1000);
});

// Add CSS for offline charts and reports
const offlineVisualizationCSS = `
    <style>
        /* Offline Chart Containers */
        .offline-charts-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 2rem;
            margin: 2rem 0;
        }
        
        .offline-chart-container {
            background: white;
            padding: 1.5rem;
            border-radius: 0.75rem;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            position: relative;
            min-height: 300px;
        }
        
        .offline-chart-container h4 {
            margin-bottom: 1rem;
            color: #2c3e50;
            font-size: 1.1rem;
        }
        
        /* CSS Pie Chart */
        .css-pie-chart {
            width: 200px;
            height: 200px;
            border-radius: 50%;
            position: relative;
            margin: 0 auto 1rem;
            background: conic-gradient(
                #3498db 0deg 60deg,
                #9b59b6 60deg 120deg,
                #e67e22 120deg 180deg,
                #1abc9c 180deg 240deg,
                #e74c3c 240deg 300deg,
                #f1c40f 300deg 360deg
            );
            animation: pieRotate 2s ease-in-out;
        }
        
        @keyframes pieRotate {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
        
        /* CSS Bar Chart */
        .css-bar-chart {
            display: flex;
            align-items: flex-end;
            justify-content: space-around;
            height: 200px;
            padding: 1rem 0;
        }
        
        .bar-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            flex: 1;
            margin: 0 0.5rem;
        }
        
        .bar-container {
            width: 40px;
            height: 150px;
            background: #e9ecef;
            border-radius: 4px 4px 0 0;
            position: relative;
            overflow: hidden;
        }
        
        .bar-fill {
            position: absolute;
            bottom: 0;
            width: 100%;
            border-radius: 4px 4px 0 0;
            transition: height 1s ease-out;
        }
        
        @keyframes barGrow {
            from { height: 0%; }
            to { height: var(--final-height, 100%); }
        }
        
        .bar-label {
            margin-top: 0.5rem;
            font-size: 0.8rem;
            font-weight: 600;
            color: #6c757d;
            text-align: center;
        }
        
        .bar-value {
            margin-top: 0.25rem;
            font-size: 0.9rem;
            font-weight: 700;
            color: #2c3e50;
        }
        
        /* CSS Donut Chart */
        .css-donut-chart {
            width: 200px;
            height: 200px;
            border-radius: 50%;
            position: relative;
            margin: 0 auto 1rem;
            background: conic-gradient(
                #27ae60 0deg calc(var(--active-percentage, 50) * 3.6deg),
                #e74c3c calc(var(--active-percentage, 50) * 3.6deg) 360deg
            );
            animation: donutSpin 2s ease-in-out;
        }
        
        .css-donut-chart::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 120px;
            height: 120px;
            background: white;
            border-radius: 50%;
            transform: translate(-50%, -50%);
        }
        
        .donut-center {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            text-align: center;
            z-index: 1;
        }
        
        .donut-total {
            font-size: 2rem;
            font-weight: 700;
            color: #2c3e50;
        }
        
        .donut-label {
            font-size: 0.9rem;
            color: #6c757d;
        }
        
        @keyframes donutSpin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
        
        /* Metrics Grid */
        .metrics-grid,
        .offline-metrics-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
        }
        
        .metric-card {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            padding: 1.5rem;
            border-radius: 0.75rem;
            text-align: center;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s ease;
        }
        
        .metric-card:hover {
            transform: translateY(-2px);
        }
        
        .metric-icon {
            font-size: 2rem;
            margin-bottom: 0.5rem;
        }
        
        .metric-value {
            font-size: 2rem;
            font-weight: 700;
            color: #2c3e50;
            margin-bottom: 0.25rem;
        }
        
        .metric-label {
            font-size: 0.9rem;
            color: #6c757d;
            margin-bottom: 0.5rem;
        }
        
        .metric-bar {
            height: 4px;
            background: #e9ecef;
            border-radius: 2px;
            overflow: hidden;
        }
        
        .metric-fill {
            height: 100%;
            border-radius: 2px;
            transition: width 1s ease-out;
        }
        
        /* Chart Legend */
        .chart-legend {
            margin-top: 1rem;
        }
        
        .legend-item {
            display: flex;
            align-items: center;
            margin-bottom: 0.5rem;
        }
        
        .legend-color {
            width: 16px;
            height: 16px;
            border-radius: 2px;
            margin-right: 0.5rem;
        }
        
        .legend-label {
            font-size: 0.9rem;
            color: #2c3e50;
        }
        
        /* Offline Reporting Interface */
        .offline-reporting-interface {
            padding: 1rem 0;
        }
        
        .reporting-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            flex-wrap: wrap;
            gap: 1rem;
        }
        
        .reporting-actions {
            display: flex;
            gap: 1rem;
        }
        
        .reporting-filters {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-bottom: 2rem;
            padding: 1.5rem;
            background: #f8f9fa;
            border-radius: 0.75rem;
        }
        
        .filter-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
            color: #495057;
        }
        
        .reporting-content {
            min-height: 400px;
        }
        
        /* Offline Report Document */
        .offline-report-document {
            background: white;
            padding: 2rem;
            border-radius: 0.75rem;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
        }
        
        .report-header {
            border-bottom: 2px solid #3498db;
            padding-bottom: 1rem;
            margin-bottom: 2rem;
        }
        
        .report-header h2 {
            color: #2c3e50;
            margin-bottom: 0.5rem;
        }
        
        .report-meta {
            color: #6c757d;
            font-size: 0.9rem;
        }
        
        .report-section {
            margin-bottom: 2rem;
        }
        
        .report-section h3 {
            color: #2c3e50;
            margin-bottom: 1rem;
            padding-bottom: 0.5rem;
            border-bottom: 1px solid #dee2e6;
        }
        
        .health-indicators {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1rem;
        }
        
        .indicator {
            background: #f8f9fa;
            padding: 1rem;
            border-radius: 0.5rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .indicator.good {
            background: rgba(39, 174, 96, 0.1);
            border-left: 4px solid #27ae60;
        }
        
        .indicator.warning {
            background: rgba(243, 156, 18, 0.1);
            border-left: 4px solid #f39c12;
        }
        
        .indicator.critical {
            background: rgba(231, 76, 60, 0.1);
            border-left: 4px solid #e74c3c;
        }
        
        .offline-report-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
        }
        
        .offline-report-table th,
        .offline-report-table td {
            border: 1px solid #dee2e6;
            padding: 0.75rem;
            text-align: left;
        }
        
        .offline-report-table th {
            background: #f8f9fa;
            font-weight: 600;
            color: #495057;
        }
        
        .status {
            padding: 0.25rem 0.5rem;
            border-radius: 0.25rem;
            font-size: 0.8rem;
            font-weight: 600;
        }
        
        .status.completed {
            background: rgba(39, 174, 96, 0.1);
            color: #27ae60;
        }
        
        .status.failed {
            background: rgba(231, 76, 60, 0.1);
            color: #e74c3c;
        }
        
        .recommendations {
            background: #e8f4fd;
            padding: 1rem;
            border-radius: 0.5rem;
            border-left: 4px solid #3498db;
        }
        
        .recommendation-item {
            margin-bottom: 0.5rem;
            color: #2c3e50;
        }
        
        .loading-state,
        .error-state {
            text-align: center;
            padding: 3rem;
            color: #6c757d;
            font-size: 1.1rem;
        }
        
        .error-state {
            color: #e74c3c;
        }
        
        .report-placeholder {
            text-align: center;
            padding: 3rem;
            color: #6c757d;
        }
        
        /* Responsive Design */
        @media (max-width: 768px) {
            .offline-charts-grid {
                grid-template-columns: 1fr;
            }
            
            .offline-chart-container {
                min-height: 250px;
            }
            
            .reporting-header {
                flex-direction: column;
                align-items: stretch;
            }
            
            .reporting-actions {
                flex-direction: column;
            }
            
            .reporting-filters {
                grid-template-columns: 1fr;
            }
            
            .metrics-grid,
            .offline-metrics-grid {
                grid-template-columns: 1fr;
            }
            
            .css-pie-chart,
            .css-donut-chart {
                width: 150px;
                height: 150px;
            }
            
            .css-bar-chart {
                height: 150px;
            }
        }
        
        /* Animation for better UX */
        .offline-chart {
            animation: fadeInUp 0.6s ease-out;
        }
        
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
`;

// Inject CSS into document head
document.head.insertAdjacentHTML('beforeend', offlineVisualizationCSS);

console.log('📊 Enhanced Offline Data Visualization and Reporting Module Loaded - Fully Offline Ready!');

