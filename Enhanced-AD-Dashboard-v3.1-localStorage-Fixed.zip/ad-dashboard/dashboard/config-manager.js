// Domain Configuration Manager - JavaScript
// Version: 3.0 - Enterprise Edition
// Comprehensive configuration management for Multi-Domain AD Dashboard

// Configuration Manager State
let configState = {
    domains: [],
    globalSettings: {},
    isDirty: false,
    validationErrors: {},
    connectivityResults: {}
};

// Default domain template
const DEFAULT_DOMAIN_TEMPLATE = {
    id: '',
    name: '',
    fqdn: '',
    description: '',
    color: '#3498db',
    priority: 1,
    enabled: true,
    location: '',
    contact: '',
    credentials: {
        useCurrentUser: true,
        username: '',
        domain: ''
    }
};

// Default global settings
const DEFAULT_GLOBAL_SETTINGS = {
    collection: {
        timeout: 300,
        retryAttempts: 3,
        parallelCollection: false,
        collectUsers: true,
        collectComputers: true,
        collectGroups: true,
        collectDomainControllers: true,
        maxUsers: 2000,
        maxComputers: 2000,
        maxGroups: 1000,
        includeDisabledObjects: true,
        collectDetailedProperties: true
    },
    output: {
        generateIndividualFiles: true,
        generateConsolidatedFile: true,
        includeTimestamps: true,
        compressOutput: false,
        logLevel: 'Verbose',
        retainLogDays: 30
    },
    dashboard: {
        title: 'Multi-Domain Active Directory Dashboard',
        refreshInterval: 30,
        defaultView: 'overview',
        enableRealTimeUpdates: true,
        maxDisplayItems: 1000
    }
};

// Domain color options
const DOMAIN_COLORS = [
    '#3498db', '#9b59b6', '#e67e22', '#1abc9c', '#e74c3c', '#f1c40f',
    '#2ecc71', '#34495e', '#f39c12', '#d35400', '#8e44ad', '#27ae60'
];

// Utility Functions
const ConfigUtils = {
    // Generate unique domain ID
    generateDomainId: function(name) {
        return name.toLowerCase()
            .replace(/[^a-z0-9]/g, '-')
            .replace(/-+/g, '-')
            .replace(/^-|-$/g, '')
            .substring(0, 20);
    },
    
    // Validate FQDN format
    validateFQDN: function(fqdn) {
        const fqdnRegex = /^[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
        return fqdnRegex.test(fqdn) && fqdn.length <= 253;
    },
    
    // Validate email format
    validateEmail: function(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    },
    
    // Sanitize input
    sanitizeInput: function(input) {
        if (typeof input !== 'string') return input;
        return input.replace(/[<>'"&]/g, '');
    },
    
    // Deep clone object
    deepClone: function(obj) {
        return JSON.parse(JSON.stringify(obj));
    },
    
    // Generate unique ID
    generateId: function() {
        return 'id_' + Math.random().toString(36).substr(2, 9);
    }
};

// Notification System
const NotificationManager = {
    show: function(message, type = 'info', duration = 5000) {
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        
        const icons = {
            success: '✅',
            error: '❌',
            warning: '⚠️',
            info: 'ℹ️'
        };
        
        notification.innerHTML = `
            <span>${icons[type] || icons.info}</span>
            <span>${message}</span>
            <button onclick="this.parentElement.remove()" style="background: none; border: none; color: inherit; font-size: 1.2rem; cursor: pointer; margin-left: auto;">×</button>
        `;
        
        document.body.appendChild(notification);
        
        if (duration > 0) {
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.remove();
                }
            }, duration);
        }
    }
};

// Configuration Manager
const ConfigManager = {
    // Initialize the configuration manager
    initialize: function() {
        console.log('🚀 Initializing Domain Configuration Manager...');
        
        try {
            // Load existing configuration
            this.loadConfiguration();
            
            // Set up event listeners
            this.setupEventListeners();
            
            // Initialize tabs
            this.initializeTabs();
            
            // Render domains
            this.renderDomains();
            
            // Load global settings
            this.loadGlobalSettings();
            
            console.log('✅ Configuration Manager initialized successfully');
            
        } catch (error) {
            console.error('❌ Error initializing Configuration Manager:', error);
            NotificationManager.show('Error initializing configuration manager', 'error');
        }
    },
    
    // Load configuration from localStorage or defaults
    loadConfiguration: function() {
        try {
            // Try to load from localStorage first
            const savedConfig = localStorage.getItem('adDashboardConfig');
            if (savedConfig) {
                const config = JSON.parse(savedConfig);
                configState.domains = config.domains || [];
                configState.globalSettings = { ...DEFAULT_GLOBAL_SETTINGS, ...config.globalSettings };
                console.log('📊 Loaded configuration from localStorage');
            } else {
                // Load default configuration
                this.loadDefaultConfiguration();
            }
        } catch (error) {
            console.error('Error loading configuration:', error);
            this.loadDefaultConfiguration();
        }
    },
    
    // Load default configuration
    loadDefaultConfiguration: function() {
        configState.domains = this.createDefaultDomains();
        configState.globalSettings = ConfigUtils.deepClone(DEFAULT_GLOBAL_SETTINGS);
        console.log('📋 Loaded default configuration');
    },
    
    // Create default domain configurations
    createDefaultDomains: function() {
        const defaultDomains = [
            {
                ...ConfigUtils.deepClone(DEFAULT_DOMAIN_TEMPLATE),
                id: 'corp-hq',
                name: 'Corporate Headquarters',
                fqdn: 'corp.company.com',
                description: 'Main corporate domain with executive and administrative users',
                color: '#3498db',
                priority: 1,
                location: 'New York, NY',
                contact: 'IT-Admin@corp.company.com'
            },
            {
                ...ConfigUtils.deepClone(DEFAULT_DOMAIN_TEMPLATE),
                id: 'sales-region',
                name: 'Sales Regional Office',
                fqdn: 'sales.company.com',
                description: 'Sales team domain with CRM and sales applications',
                color: '#9b59b6',
                priority: 2,
                location: 'Chicago, IL',
                contact: 'Sales-IT@sales.company.com'
            },
            {
                ...ConfigUtils.deepClone(DEFAULT_DOMAIN_TEMPLATE),
                id: 'dev-environment',
                name: 'Development Environment',
                fqdn: 'dev.company.com',
                description: 'Development and testing domain for software teams',
                color: '#e67e22',
                priority: 3,
                location: 'Austin, TX',
                contact: 'DevOps@dev.company.com'
            },
            {
                ...ConfigUtils.deepClone(DEFAULT_DOMAIN_TEMPLATE),
                id: 'manufacturing',
                name: 'Manufacturing Division',
                fqdn: 'mfg.company.com',
                description: 'Manufacturing and production domain with industrial systems',
                color: '#1abc9c',
                priority: 4,
                location: 'Detroit, MI',
                contact: 'MFG-IT@mfg.company.com'
            },
            {
                ...ConfigUtils.deepClone(DEFAULT_DOMAIN_TEMPLATE),
                id: 'finance-dept',
                name: 'Finance Department',
                fqdn: 'finance.company.com',
                description: 'Finance and accounting domain with sensitive financial data',
                color: '#e74c3c',
                priority: 5,
                location: 'Boston, MA',
                contact: 'Finance-IT@finance.company.com'
            },
            {
                ...ConfigUtils.deepClone(DEFAULT_DOMAIN_TEMPLATE),
                id: 'research-lab',
                name: 'Research Laboratory',
                fqdn: 'research.company.com',
                description: 'Research and development domain with scientific applications',
                color: '#f1c40f',
                priority: 6,
                location: 'San Francisco, CA',
                contact: 'Research-IT@research.company.com'
            }
        ];
        
        return defaultDomains;
    },
    
    // Set up event listeners
    setupEventListeners: function() {
        // Tab switching
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const tabName = e.target.getAttribute('data-tab');
                this.switchTab(tabName);
            });
        });
        
        // Auto-save on changes
        document.addEventListener('input', (e) => {
            if (e.target.matches('.form-input, .form-select, .form-textarea, .form-check-input')) {
                configState.isDirty = true;
                this.autoSave();
            }
        });
        
        // Prevent accidental navigation
        window.addEventListener('beforeunload', (e) => {
            if (configState.isDirty) {
                e.preventDefault();
                e.returnValue = 'You have unsaved changes. Are you sure you want to leave?';
            }
        });
    },
    
    // Initialize tabs
    initializeTabs: function() {
        this.switchTab('domains');
    },
    
    // Switch tabs
    switchTab: function(tabName) {
        // Update tab buttons
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
        
        // Update tab content
        document.querySelectorAll('.tab-panel').forEach(panel => {
            panel.style.display = 'none';
        });
        document.getElementById(`${tabName}-tab`).style.display = 'block';
        
        console.log('🔄 Switched to tab:', tabName);
    },
    
    // Render domain configuration cards
    renderDomains: function() {
        const container = document.getElementById('domainsGrid');
        if (!container) return;
        
        container.innerHTML = '';
        
        configState.domains.forEach((domain, index) => {
            const card = this.createDomainCard(domain, index);
            container.appendChild(card);
        });
        
        console.log('🏢 Rendered', configState.domains.length, 'domain configurations');
    },
    
    // Create domain configuration card
    createDomainCard: function(domain, index) {
        const card = document.createElement('div');
        card.className = `domain-config-card ${domain.enabled ? 'enabled' : 'disabled'}`;
        card.setAttribute('data-domain-index', index);
        
        card.innerHTML = `
            <div class="domain-header">
                <h3 class="domain-title">${ConfigUtils.sanitizeInput(domain.name || 'New Domain')}</h3>
                <span class="domain-status ${domain.enabled ? 'status-enabled' : 'status-disabled'}">
                    ${domain.enabled ? 'Enabled' : 'Disabled'}
                </span>
            </div>
            
            <div class="form-group">
                <label class="form-label">Domain ID</label>
                <input type="text" class="form-input" value="${domain.id}" 
                       onchange="ConfigManager.updateDomain(${index}, 'id', this.value)"
                       pattern="[a-z0-9-]+" title="Lowercase letters, numbers, and hyphens only">
                <div class="form-help">Unique identifier (lowercase, no spaces)</div>
            </div>
            
            <div class="form-group">
                <label class="form-label">Domain Name</label>
                <input type="text" class="form-input" value="${domain.name}" 
                       onchange="ConfigManager.updateDomain(${index}, 'name', this.value)"
                       required>
                <div class="form-help">Friendly display name</div>
            </div>
            
            <div class="form-group">
                <label class="form-label">FQDN</label>
                <input type="text" class="form-input" value="${domain.fqdn}" 
                       onchange="ConfigManager.updateDomain(${index}, 'fqdn', this.value)"
                       placeholder="domain.company.com" required>
                <div class="form-help">Fully qualified domain name</div>
            </div>
            
            <div class="form-group">
                <label class="form-label">Description</label>
                <textarea class="form-textarea" rows="2" 
                          onchange="ConfigManager.updateDomain(${index}, 'description', this.value)"
                          placeholder="Brief description of this domain">${domain.description}</textarea>
            </div>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                <div class="form-group">
                    <label class="form-label">Priority</label>
                    <input type="number" class="form-input" value="${domain.priority}" min="1" max="10"
                           onchange="ConfigManager.updateDomain(${index}, 'priority', parseInt(this.value))">
                </div>
                <div class="form-group">
                    <label class="form-label">Color</label>
                    <select class="form-select" onchange="ConfigManager.updateDomain(${index}, 'color', this.value)">
                        ${DOMAIN_COLORS.map(color => 
                            `<option value="${color}" ${domain.color === color ? 'selected' : ''} 
                             style="background: ${color}; color: white;">●</option>`
                        ).join('')}
                    </select>
                </div>
            </div>
            
            <div class="form-group">
                <label class="form-label">Location</label>
                <input type="text" class="form-input" value="${domain.location}" 
                       onchange="ConfigManager.updateDomain(${index}, 'location', this.value)"
                       placeholder="City, State/Country">
            </div>
            
            <div class="form-group">
                <label class="form-label">Contact Email</label>
                <input type="email" class="form-input" value="${domain.contact}" 
                       onchange="ConfigManager.updateDomain(${index}, 'contact', this.value)"
                       placeholder="admin@domain.com">
            </div>
            
            <div class="form-check">
                <input type="checkbox" class="form-check-input" id="enabled-${index}" 
                       ${domain.enabled ? 'checked' : ''}
                       onchange="ConfigManager.updateDomain(${index}, 'enabled', this.checked)">
                <label class="form-check-label" for="enabled-${index}">Enable this domain for data collection</label>
            </div>
            
            <div class="domain-actions">
                <button class="btn btn-sm btn-primary" onclick="ConfigManager.testConnectivity(${index})">
                    <span>🔍</span>
                    Test Connection
                </button>
                <button class="btn btn-sm btn-secondary" onclick="ConfigManager.duplicateDomain(${index})">
                    <span>📋</span>
                    Duplicate
                </button>
                <button class="btn btn-sm btn-danger" onclick="ConfigManager.removeDomain(${index})">
                    <span>🗑️</span>
                    Remove
                </button>
            </div>
            
            <div class="connectivity-test" id="connectivity-${index}">
                <div class="spinner"></div>
                Testing connectivity...
            </div>
        `;
        
        return card;
    },
    
    // Update domain property
    updateDomain: function(index, property, value) {
        if (index < 0 || index >= configState.domains.length) return;
        
        // Validate input
        value = ConfigUtils.sanitizeInput(value);
        
        // Special validation for certain fields
        if (property === 'id') {
            value = ConfigUtils.generateDomainId(value);
            // Check for duplicates
            const existingIds = configState.domains.map((d, i) => i !== index ? d.id : null);
            if (existingIds.includes(value)) {
                NotificationManager.show('Domain ID must be unique', 'error');
                return;
            }
        } else if (property === 'fqdn' && value && !ConfigUtils.validateFQDN(value)) {
            NotificationManager.show('Invalid FQDN format', 'error');
            return;
        } else if (property === 'contact' && value && !ConfigUtils.validateEmail(value)) {
            NotificationManager.show('Invalid email format', 'error');
            return;
        }
        
        // Update the domain
        configState.domains[index][property] = value;
        configState.isDirty = true;
        
        // Re-render if necessary
        if (property === 'name' || property === 'enabled') {
            this.renderDomains();
        }
        
        console.log('📝 Updated domain', index, property, '=', value);
    },
    
    // Add new domain
    addNewDomain: function() {
        if (configState.domains.length >= 6) {
            NotificationManager.show('Maximum of 6 domains supported', 'warning');
            return;
        }
        
        const newDomain = {
            ...ConfigUtils.deepClone(DEFAULT_DOMAIN_TEMPLATE),
            id: `domain-${configState.domains.length + 1}`,
            name: `Domain ${configState.domains.length + 1}`,
            priority: configState.domains.length + 1,
            color: DOMAIN_COLORS[configState.domains.length % DOMAIN_COLORS.length]
        };
        
        configState.domains.push(newDomain);
        configState.isDirty = true;
        
        this.renderDomains();
        NotificationManager.show('New domain added', 'success');
        
        console.log('➕ Added new domain');
    },
    
    // Remove domain
    removeDomain: function(index) {
        if (index < 0 || index >= configState.domains.length) return;
        
        const domain = configState.domains[index];
        if (confirm(`Are you sure you want to remove "${domain.name}"?`)) {
            configState.domains.splice(index, 1);
            configState.isDirty = true;
            
            this.renderDomains();
            NotificationManager.show('Domain removed', 'success');
            
            console.log('🗑️ Removed domain:', domain.name);
        }
    },
    
    // Duplicate domain
    duplicateDomain: function(index) {
        if (index < 0 || index >= configState.domains.length) return;
        if (configState.domains.length >= 6) {
            NotificationManager.show('Maximum of 6 domains supported', 'warning');
            return;
        }
        
        const originalDomain = configState.domains[index];
        const duplicatedDomain = {
            ...ConfigUtils.deepClone(originalDomain),
            id: `${originalDomain.id}-copy`,
            name: `${originalDomain.name} (Copy)`,
            priority: configState.domains.length + 1
        };
        
        configState.domains.push(duplicatedDomain);
        configState.isDirty = true;
        
        this.renderDomains();
        NotificationManager.show('Domain duplicated', 'success');
        
        console.log('📋 Duplicated domain:', originalDomain.name);
    },
    
    // Test domain connectivity
    testConnectivity: function(index) {
        if (index < 0 || index >= configState.domains.length) return;
        
        const domain = configState.domains[index];
        const testElement = document.getElementById(`connectivity-${index}`);
        
        if (!domain.fqdn) {
            NotificationManager.show('Please enter a valid FQDN first', 'warning');
            return;
        }
        
        // Show test in progress
        testElement.classList.add('show');
        testElement.style.background = '#3498db';
        testElement.innerHTML = '<div class="spinner"></div> Testing connectivity...';
        
        // Simulate connectivity test (in real implementation, this would call PowerShell)
        setTimeout(() => {
            const isValid = ConfigUtils.validateFQDN(domain.fqdn);
            const success = isValid && Math.random() > 0.3; // Simulate 70% success rate
            
            if (success) {
                testElement.style.background = '#27ae60';
                testElement.innerHTML = '✅ Connection successful';
                configState.connectivityResults[index] = { success: true, message: 'Connection successful' };
            } else {
                testElement.style.background = '#e74c3c';
                testElement.innerHTML = '❌ Connection failed - Check FQDN and network connectivity';
                configState.connectivityResults[index] = { success: false, message: 'Connection failed' };
            }
            
            // Hide after 5 seconds
            setTimeout(() => {
                testElement.classList.remove('show');
            }, 5000);
            
        }, 2000);
        
        console.log('🔍 Testing connectivity for:', domain.name);
    },
    
    // Load global settings into form
    loadGlobalSettings: function() {
        const settings = configState.globalSettings;
        
        // Collection settings
        this.setFormValue('collectionTimeout', settings.collection.timeout);
        this.setFormValue('retryAttempts', settings.collection.retryAttempts);
        this.setFormValue('parallelCollection', settings.collection.parallelCollection);
        this.setFormValue('maxUsers', settings.collection.maxUsers);
        this.setFormValue('maxComputers', settings.collection.maxComputers);
        this.setFormValue('maxGroups', settings.collection.maxGroups);
        
        // Dashboard settings
        this.setFormValue('dashboardTitle', settings.dashboard.title);
        this.setFormValue('refreshInterval', settings.dashboard.refreshInterval);
        this.setFormValue('enableRealTimeUpdates', settings.dashboard.enableRealTimeUpdates);
        
        console.log('⚙️ Loaded global settings');
    },
    
    // Set form value helper
    setFormValue: function(id, value) {
        const element = document.getElementById(id);
        if (element) {
            if (element.type === 'checkbox') {
                element.checked = value;
            } else {
                element.value = value;
            }
            
            // Add change listener
            element.addEventListener('change', () => {
                this.updateGlobalSetting(id, element.type === 'checkbox' ? element.checked : element.value);
            });
        }
    },
    
    // Update global setting
    updateGlobalSetting: function(id, value) {
        // Map form IDs to settings paths
        const settingsMap = {
            'collectionTimeout': 'collection.timeout',
            'retryAttempts': 'collection.retryAttempts',
            'parallelCollection': 'collection.parallelCollection',
            'maxUsers': 'collection.maxUsers',
            'maxComputers': 'collection.maxComputers',
            'maxGroups': 'collection.maxGroups',
            'dashboardTitle': 'dashboard.title',
            'refreshInterval': 'dashboard.refreshInterval',
            'enableRealTimeUpdates': 'dashboard.enableRealTimeUpdates'
        };
        
        const path = settingsMap[id];
        if (path) {
            const pathParts = path.split('.');
            let target = configState.globalSettings;
            
            for (let i = 0; i < pathParts.length - 1; i++) {
                target = target[pathParts[i]];
            }
            
            target[pathParts[pathParts.length - 1]] = value;
            configState.isDirty = true;
            
            console.log('⚙️ Updated global setting:', path, '=', value);
        }
    },
    
    // Auto-save configuration
    autoSave: function() {
        try {
            const config = {
                domains: configState.domains,
                globalSettings: configState.globalSettings,
                lastModified: new Date().toISOString()
            };
            
            localStorage.setItem('adDashboardConfig', JSON.stringify(config));
            console.log('💾 Auto-saved configuration');
            
        } catch (error) {
            console.error('Error auto-saving configuration:', error);
        }
    },
    
    // Save all configurations
    saveAllConfigurations: function() {
        try {
            // Validate all domains
            const errors = this.validateAllDomains();
            if (errors.length > 0) {
                NotificationManager.show(`Validation errors: ${errors.join(', ')}`, 'error');
                return;
            }
            
            // Save to localStorage
            this.autoSave();
            
            // Generate PowerShell configuration file
            this.generatePowerShellConfig();
            
            configState.isDirty = false;
            NotificationManager.show('Configuration saved successfully', 'success');
            
            console.log('💾 All configurations saved');
            
        } catch (error) {
            console.error('Error saving configurations:', error);
            NotificationManager.show('Error saving configuration', 'error');
        }
    },
    
    // Validate all domains
    validateAllDomains: function() {
        const errors = [];
        
        configState.domains.forEach((domain, index) => {
            if (!domain.id) errors.push(`Domain ${index + 1}: Missing ID`);
            if (!domain.name) errors.push(`Domain ${index + 1}: Missing name`);
            if (!domain.fqdn) errors.push(`Domain ${index + 1}: Missing FQDN`);
            if (domain.fqdn && !ConfigUtils.validateFQDN(domain.fqdn)) {
                errors.push(`Domain ${index + 1}: Invalid FQDN format`);
            }
            if (domain.contact && !ConfigUtils.validateEmail(domain.contact)) {
                errors.push(`Domain ${index + 1}: Invalid email format`);
            }
        });
        
        // Check for duplicate IDs
        const ids = configState.domains.map(d => d.id);
        const duplicateIds = ids.filter((id, index) => ids.indexOf(id) !== index);
        if (duplicateIds.length > 0) {
            errors.push(`Duplicate domain IDs: ${duplicateIds.join(', ')}`);
        }
        
        return errors;
    },
    
    // Generate PowerShell configuration file
    generatePowerShellConfig: function() {
        const config = {
            metadata: {
                version: '3.0',
                created: new Date().toISOString(),
                description: 'Enhanced Multi-Domain Active Directory Configuration'
            },
            domains: configState.domains,
            collection: configState.globalSettings.collection,
            output: configState.globalSettings.output,
            dashboard: configState.globalSettings.dashboard
        };
        
        // Store for download
        window.generatedConfig = config;
        
        console.log('📋 Generated PowerShell configuration');
    }
};

// Global Functions
function addNewDomain() {
    ConfigManager.addNewDomain();
}

function saveAllConfigurations() {
    ConfigManager.saveAllConfigurations();
}

function exportConfiguration() {
    try {
        const config = {
            domains: configState.domains,
            globalSettings: configState.globalSettings,
            metadata: {
                version: '3.0',
                exported: new Date().toISOString(),
                exportedBy: 'Domain Configuration Manager'
            }
        };
        
        const blob = new Blob([JSON.stringify(config, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement('a');
        a.href = url;
        a.download = `ad-dashboard-config-${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        NotificationManager.show('Configuration exported successfully', 'success');
        
    } catch (error) {
        console.error('Error exporting configuration:', error);
        NotificationManager.show('Error exporting configuration', 'error');
    }
}

function exportSampleConfiguration() {
    try {
        const sampleConfig = {
            domains: ConfigManager.createDefaultDomains(),
            globalSettings: DEFAULT_GLOBAL_SETTINGS,
            metadata: {
                version: '3.0',
                type: 'sample',
                exported: new Date().toISOString(),
                description: 'Sample configuration for Multi-Domain AD Dashboard'
            }
        };
        
        const blob = new Blob([JSON.stringify(sampleConfig, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement('a');
        a.href = url;
        a.download = 'ad-dashboard-sample-config.json';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        NotificationManager.show('Sample configuration exported', 'success');
        
    } catch (error) {
        console.error('Error exporting sample configuration:', error);
        NotificationManager.show('Error exporting sample configuration', 'error');
    }
}

function importConfiguration(input) {
    const file = input.files[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = function(e) {
        try {
            const config = JSON.parse(e.target.result);
            
            // Validate configuration
            if (!config.domains || !Array.isArray(config.domains)) {
                throw new Error('Invalid configuration format: missing domains array');
            }
            
            // Import configuration
            configState.domains = config.domains;
            if (config.globalSettings) {
                configState.globalSettings = { ...DEFAULT_GLOBAL_SETTINGS, ...config.globalSettings };
            }
            
            configState.isDirty = true;
            
            // Re-render
            ConfigManager.renderDomains();
            ConfigManager.loadGlobalSettings();
            
            NotificationManager.show('Configuration imported successfully', 'success');
            
        } catch (error) {
            console.error('Error importing configuration:', error);
            NotificationManager.show('Error importing configuration: ' + error.message, 'error');
        }
    };
    
    reader.readAsText(file);
}

function resetToDefaults() {
    if (confirm('Are you sure you want to reset to default configuration? This will lose all current settings.')) {
        ConfigManager.loadDefaultConfiguration();
        ConfigManager.renderDomains();
        ConfigManager.loadGlobalSettings();
        
        configState.isDirty = true;
        NotificationManager.show('Configuration reset to defaults', 'success');
    }
}

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    ConfigManager.initialize();
});

console.log('⚙️ Domain Configuration Manager Script Loaded - Ready!');

