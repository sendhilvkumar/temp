// Sample Active Directory Data for Demo Dashboard
// This data represents a realistic multi-domain enterprise environment

const SAMPLE_AD_DATA = {
    "metadata": {
        "collectionTime": "2025-06-26T10:30:00Z",
        "version": "3.1",
        "totalDomains": 6,
        "collectionDuration": "00:02:45",
        "environment": "Demo Environment"
    },
    "domainData": {
        "corp-hq": {
            "info": {
                "id": "corp-hq",
                "name": "Corporate Headquarters",
                "fqdn": "corp.company.com",
                "description": "Main corporate domain with executive and administrative users",
                "location": "New York, NY",
                "contactEmail": "IT-Admin@corp.company.com",
                "priority": 1,
                "color": "#3498db"
            },
            "status": "Completed",
            "summary": {
                "totalUsers": 2847,
                "activeUsers": 2654,
                "disabledUsers": 193,
                "lockedUsers": 12,
                "totalComputers": 1523,
                "activeComputers": 1445,
                "inactiveComputers": 78,
                "totalGroups": 456,
                "securityGroups": 234,
                "distributionGroups": 222,
                "domainControllers": 4,
                "lastLogon": "2025-06-26T10:25:00Z"
            },
            "details": {
                "users": {
                    "executives": 45,
                    "managers": 234,
                    "employees": 2375,
                    "contractors": 193,
                    "serviceAccounts": 67
                },
                "computers": {
                    "workstations": 1234,
                    "laptops": 234,
                    "servers": 55
                },
                "security": {
                    "adminAccounts": 23,
                    "privilegedGroups": 12,
                    "passwordPolicy": "Compliant",
                    "lastAudit": "2025-06-20"
                }
            }
        },
        "sales-region": {
            "info": {
                "id": "sales-region",
                "name": "Sales Regional Office",
                "fqdn": "sales.company.com",
                "description": "Sales team domain with CRM and sales applications",
                "location": "Chicago, IL",
                "contactEmail": "Sales-IT@sales.company.com",
                "priority": 2,
                "color": "#9b59b6"
            },
            "status": "Completed",
            "summary": {
                "totalUsers": 1234,
                "activeUsers": 1156,
                "disabledUsers": 78,
                "lockedUsers": 3,
                "totalComputers": 867,
                "activeComputers": 823,
                "inactiveComputers": 44,
                "totalGroups": 189,
                "securityGroups": 98,
                "distributionGroups": 91,
                "domainControllers": 2,
                "lastLogon": "2025-06-26T10:28:00Z"
            },
            "details": {
                "users": {
                    "salesReps": 456,
                    "managers": 67,
                    "support": 234,
                    "contractors": 89,
                    "serviceAccounts": 34
                },
                "computers": {
                    "workstations": 567,
                    "laptops": 234,
                    "servers": 66
                },
                "security": {
                    "adminAccounts": 12,
                    "privilegedGroups": 8,
                    "passwordPolicy": "Compliant",
                    "lastAudit": "2025-06-18"
                }
            }
        },
        "dev-environment": {
            "info": {
                "id": "dev-environment",
                "name": "Development Environment",
                "fqdn": "dev.company.com",
                "description": "Development and testing environment for IT projects",
                "location": "Austin, TX",
                "contactEmail": "DevOps@dev.company.com",
                "priority": 3,
                "color": "#e67e22"
            },
            "status": "Completed",
            "summary": {
                "totalUsers": 456,
                "activeUsers": 398,
                "disabledUsers": 58,
                "lockedUsers": 1,
                "totalComputers": 234,
                "activeComputers": 198,
                "inactiveComputers": 36,
                "totalGroups": 123,
                "securityGroups": 67,
                "distributionGroups": 56,
                "domainControllers": 2,
                "lastLogon": "2025-06-26T10:22:00Z"
            },
            "details": {
                "users": {
                    "developers": 234,
                    "testers": 89,
                    "devOps": 45,
                    "contractors": 67,
                    "serviceAccounts": 21
                },
                "computers": {
                    "workstations": 123,
                    "laptops": 67,
                    "servers": 44
                },
                "security": {
                    "adminAccounts": 15,
                    "privilegedGroups": 6,
                    "passwordPolicy": "Compliant",
                    "lastAudit": "2025-06-15"
                }
            }
        },
        "manufacturing": {
            "info": {
                "id": "manufacturing",
                "name": "Manufacturing Division",
                "fqdn": "mfg.company.com",
                "description": "Manufacturing and production facilities domain",
                "location": "Detroit, MI",
                "contactEmail": "MfgIT@mfg.company.com",
                "priority": 2,
                "color": "#1abc9c"
            },
            "status": "Completed",
            "summary": {
                "totalUsers": 1876,
                "activeUsers": 1734,
                "disabledUsers": 142,
                "lockedUsers": 8,
                "totalComputers": 1234,
                "activeComputers": 1156,
                "inactiveComputers": 78,
                "totalGroups": 234,
                "securityGroups": 134,
                "distributionGroups": 100,
                "domainControllers": 3,
                "lastLogon": "2025-06-26T10:26:00Z"
            },
            "details": {
                "users": {
                    "operators": 1234,
                    "supervisors": 234,
                    "engineers": 189,
                    "contractors": 156,
                    "serviceAccounts": 63
                },
                "computers": {
                    "workstations": 789,
                    "laptops": 123,
                    "servers": 322
                },
                "security": {
                    "adminAccounts": 18,
                    "privilegedGroups": 9,
                    "passwordPolicy": "Compliant",
                    "lastAudit": "2025-06-22"
                }
            }
        },
        "finance-dept": {
            "info": {
                "id": "finance-dept",
                "name": "Finance Department",
                "fqdn": "finance.company.com",
                "description": "Finance and accounting department domain",
                "location": "New York, NY",
                "contactEmail": "FinanceIT@finance.company.com",
                "priority": 1,
                "color": "#e74c3c"
            },
            "status": "Completed",
            "summary": {
                "totalUsers": 567,
                "activeUsers": 523,
                "disabledUsers": 44,
                "lockedUsers": 2,
                "totalComputers": 345,
                "activeComputers": 323,
                "inactiveComputers": 22,
                "totalGroups": 89,
                "securityGroups": 56,
                "distributionGroups": 33,
                "domainControllers": 2,
                "lastLogon": "2025-06-26T10:29:00Z"
            },
            "details": {
                "users": {
                    "accountants": 234,
                    "analysts": 123,
                    "managers": 45,
                    "contractors": 67,
                    "serviceAccounts": 98
                },
                "computers": {
                    "workstations": 234,
                    "laptops": 89,
                    "servers": 22
                },
                "security": {
                    "adminAccounts": 8,
                    "privilegedGroups": 5,
                    "passwordPolicy": "Compliant",
                    "lastAudit": "2025-06-25"
                }
            }
        },
        "research-lab": {
            "info": {
                "id": "research-lab",
                "name": "Research Laboratory",
                "fqdn": "research.company.com",
                "description": "Research and development laboratory domain",
                "location": "San Francisco, CA",
                "contactEmail": "ResearchIT@research.company.com",
                "priority": 3,
                "color": "#f1c40f"
            },
            "status": "Completed",
            "summary": {
                "totalUsers": 234,
                "activeUsers": 198,
                "disabledUsers": 36,
                "lockedUsers": 1,
                "totalComputers": 156,
                "activeComputers": 134,
                "inactiveComputers": 22,
                "totalGroups": 67,
                "securityGroups": 34,
                "distributionGroups": 33,
                "domainControllers": 2,
                "lastLogon": "2025-06-26T10:20:00Z"
            },
            "details": {
                "users": {
                    "researchers": 123,
                    "scientists": 67,
                    "technicians": 34,
                    "contractors": 10,
                    "serviceAccounts": 0
                },
                "computers": {
                    "workstations": 89,
                    "laptops": 45,
                    "servers": 22
                },
                "security": {
                    "adminAccounts": 6,
                    "privilegedGroups": 3,
                    "passwordPolicy": "Compliant",
                    "lastAudit": "2025-06-19"
                }
            }
        }
    },
    "aggregatedSummary": {
        "totalUsers": 7214,
        "activeUsers": 6663,
        "disabledUsers": 551,
        "lockedUsers": 27,
        "totalComputers": 4359,
        "activeComputers": 4079,
        "inactiveComputers": 280,
        "totalGroups": 1158,
        "securityGroups": 623,
        "distributionGroups": 535,
        "totalDomainControllers": 15,
        "healthScore": 92.3,
        "complianceScore": 98.5
    },
    "alerts": [
        {
            "type": "warning",
            "domain": "corp-hq",
            "message": "12 locked user accounts require attention",
            "severity": "medium",
            "timestamp": "2025-06-26T10:25:00Z"
        },
        {
            "type": "info",
            "domain": "dev-environment",
            "message": "Scheduled maintenance completed successfully",
            "severity": "low",
            "timestamp": "2025-06-26T09:15:00Z"
        },
        {
            "type": "success",
            "domain": "finance-dept",
            "message": "Security audit passed with 98.5% compliance",
            "severity": "low",
            "timestamp": "2025-06-25T16:30:00Z"
        }
    ],
    "trends": {
        "userGrowth": "+2.3%",
        "computerGrowth": "+1.8%",
        "securityIncidents": "-15%",
        "systemUptime": "99.7%"
    }
};

// Export for use in demo dashboard
if (typeof module !== 'undefined' && module.exports) {
    module.exports = SAMPLE_AD_DATA;
}

