@echo off
setlocal EnableDelayedExpansion

REM Enhanced Multi-Domain Active Directory Dashboard - Deployment Script
REM Version: 3.0 - Enterprise Edition
REM This script packages the complete dashboard solution for deployment

echo.
echo ========================================================================
echo Enhanced Multi-Domain Active Directory Dashboard - Deployment Package
echo Version 3.0 - Enterprise Edition
echo ========================================================================
echo.

REM Set variables
set "SOURCE_DIR=%~dp0"
set "PACKAGE_NAME=Enhanced-AD-Dashboard-v3.0"
set "TIMESTAMP=%date:~-4,4%%date:~-10,2%%date:~-7,2%_%time:~0,2%%time:~3,2%%time:~6,2%"
set "TIMESTAMP=!TIMESTAMP: =0!"
set "PACKAGE_DIR=%SOURCE_DIR%\%PACKAGE_NAME%"
set "ZIP_FILE=%SOURCE_DIR%\%PACKAGE_NAME%-%TIMESTAMP%.zip"

echo Creating deployment package...
echo Source Directory: %SOURCE_DIR%
echo Package Directory: %PACKAGE_DIR%
echo.

REM Create package directory structure
if exist "%PACKAGE_DIR%" (
    echo Removing existing package directory...
    rmdir /s /q "%PACKAGE_DIR%"
)

echo Creating directory structure...
mkdir "%PACKAGE_DIR%"
mkdir "%PACKAGE_DIR%\dashboard"
mkdir "%PACKAGE_DIR%\scripts"
mkdir "%PACKAGE_DIR%\docs"
mkdir "%PACKAGE_DIR%\data"
mkdir "%PACKAGE_DIR%\data\individual"
mkdir "%PACKAGE_DIR%\data\consolidated"
mkdir "%PACKAGE_DIR%\logs"
mkdir "%PACKAGE_DIR%\assets"
mkdir "%PACKAGE_DIR%\assets\css"
mkdir "%PACKAGE_DIR%\assets\js"
mkdir "%PACKAGE_DIR%\assets\images"

REM Copy dashboard files
echo Copying dashboard files...
copy "%SOURCE_DIR%\dashboard\index.html" "%PACKAGE_DIR%\dashboard\" >nul
copy "%SOURCE_DIR%\dashboard\config.html" "%PACKAGE_DIR%\dashboard\" >nul
copy "%SOURCE_DIR%\dashboard\script.js" "%PACKAGE_DIR%\dashboard\" >nul
copy "%SOURCE_DIR%\dashboard\config-manager.js" "%PACKAGE_DIR%\dashboard\" >nul
copy "%SOURCE_DIR%\dashboard\visualization.js" "%PACKAGE_DIR%\dashboard\" >nul

REM Copy PowerShell scripts
echo Copying PowerShell scripts...
copy "%SOURCE_DIR%\scripts\Enhanced-Multi-Domain-AD-Collector.ps1" "%PACKAGE_DIR%\scripts\" >nul
copy "%SOURCE_DIR%\scripts\Dashboard-Data-Embedder.ps1" "%PACKAGE_DIR%\scripts\" >nul
copy "%SOURCE_DIR%\scripts\Run-Enhanced-AD-Dashboard.bat" "%PACKAGE_DIR%\scripts\" >nul

REM Copy documentation
echo Copying documentation...
copy "%SOURCE_DIR%\docs\README.md" "%PACKAGE_DIR%\docs\" >nul
copy "%SOURCE_DIR%\docs\USER-GUIDE.md" "%PACKAGE_DIR%\docs\" >nul
copy "%SOURCE_DIR%\docs\TECHNICAL-GUIDE.md" "%PACKAGE_DIR%\docs\" >nul
copy "%SOURCE_DIR%\docs\design-specification.md" "%PACKAGE_DIR%\docs\" >nul

REM Create sample data files
echo Creating sample data structure...
echo {"message": "Data files will be generated here after running collection script"} > "%PACKAGE_DIR%\data\consolidated\README.json"
echo {"message": "Individual domain data files will be stored here"} > "%PACKAGE_DIR%\data\individual\README.json"
echo Collection logs will be stored in this directory > "%PACKAGE_DIR%\logs\README.txt"

REM Create installation script
echo Creating installation script...
(
echo @echo off
echo setlocal EnableDelayedExpansion
echo.
echo echo ========================================================================
echo echo Enhanced Multi-Domain Active Directory Dashboard - Installation
echo echo Version 3.0 - Enterprise Edition
echo echo ========================================================================
echo echo.
echo.
echo REM Check PowerShell version
echo echo Checking PowerShell version...
echo powershell -Command "if ($PSVersionTable.PSVersion.Major -lt 5) { Write-Host 'ERROR: PowerShell 5.0 or later is required' -ForegroundColor Red; exit 1 } else { Write-Host 'PowerShell version OK' -ForegroundColor Green }"
echo if errorlevel 1 goto :error
echo.
echo REM Check Active Directory module
echo echo Checking Active Directory module...
echo powershell -Command "try { Import-Module ActiveDirectory -ErrorAction Stop; Write-Host 'Active Directory module OK' -ForegroundColor Green } catch { Write-Host 'ERROR: Active Directory module not found. Please install RSAT.' -ForegroundColor Red; exit 1 }"
echo if errorlevel 1 goto :error
echo.
echo echo Installation checks completed successfully!
echo echo.
echo echo Next steps:
echo echo 1. Open dashboard\config.html to configure your domains
echo echo 2. Run scripts\Run-Enhanced-AD-Dashboard.bat to collect data
echo echo 3. Open dashboard\index.html to view your dashboard
echo echo.
echo echo For detailed instructions, see docs\README.md
echo echo.
echo pause
echo goto :end
echo.
echo :error
echo echo.
echo echo Installation failed. Please resolve the errors above and try again.
echo echo.
echo pause
echo.
echo :end
) > "%PACKAGE_DIR%\INSTALL.bat"

REM Create quick start guide
echo Creating quick start guide...
(
echo # Quick Start Guide
echo.
echo ## Installation
echo 1. Extract all files to a directory like C:\AD-Dashboard
echo 2. Run INSTALL.bat to verify prerequisites
echo.
echo ## Configuration
echo 1. Open dashboard\config.html in your web browser
echo 2. Configure your Active Directory domains
echo 3. Test connectivity to each domain
echo 4. Save configuration
echo.
echo ## Data Collection
echo 1. Run scripts\Run-Enhanced-AD-Dashboard.bat
echo 2. Wait for data collection to complete
echo.
echo ## View Dashboard
echo 1. Open dashboard\index.html in your web browser
echo 2. Explore your Active Directory data
echo.
echo For detailed instructions, see docs\README.md
) > "%PACKAGE_DIR%\QUICK-START.md"

REM Create version info file
echo Creating version information...
(
echo Enhanced Multi-Domain Active Directory Dashboard
echo Version: 3.0 - Enterprise Edition
echo Build Date: %date% %time%
echo.
echo Components:
echo - Multi-domain data collection engine
echo - Web-based configuration interface
echo - Interactive dashboard with charts
echo - Advanced reporting and analytics
echo - Data export capabilities
echo.
echo Requirements:
echo - Windows 10/11 or Windows Server 2016+
echo - PowerShell 5.0 or later
echo - Active Directory PowerShell module ^(RSAT^)
echo - Modern web browser
echo.
echo For support and documentation, see the docs folder.
) > "%PACKAGE_DIR%\VERSION.txt"

REM Create directory listing
echo Creating file inventory...
(
echo Enhanced Multi-Domain Active Directory Dashboard - File Inventory
echo Generated: %date% %time%
echo.
echo DASHBOARD FILES:
echo   dashboard\index.html              - Main dashboard interface
echo   dashboard\config.html             - Configuration interface
echo   dashboard\script.js               - Core dashboard functionality
echo   dashboard\config-manager.js       - Configuration management
echo   dashboard\visualization.js        - Charts and reporting
echo.
echo POWERSHELL SCRIPTS:
echo   scripts\Enhanced-Multi-Domain-AD-Collector.ps1  - Data collection engine
echo   scripts\Dashboard-Data-Embedder.ps1             - Data integration
echo   scripts\Run-Enhanced-AD-Dashboard.bat           - Execution wrapper
echo.
echo DOCUMENTATION:
echo   docs\README.md                    - Overview and installation
echo   docs\USER-GUIDE.md               - Detailed user instructions
echo   docs\TECHNICAL-GUIDE.md          - Technical implementation
echo   docs\design-specification.md     - Design and architecture
echo.
echo DATA DIRECTORIES:
echo   data\consolidated\                - Aggregated data files
echo   data\individual\                  - Per-domain data files
echo   logs\                            - Collection logs
echo.
echo INSTALLATION:
echo   INSTALL.bat                      - Installation verification
echo   QUICK-START.md                   - Quick start instructions
echo   VERSION.txt                      - Version information
echo   INVENTORY.txt                    - This file
) > "%PACKAGE_DIR%\INVENTORY.txt"

echo.
echo Package creation completed successfully!
echo.
echo Package Contents:
echo - Dashboard files: 5 files
echo - PowerShell scripts: 3 files
echo - Documentation: 4 files
echo - Installation files: 4 files
echo - Directory structure: 8 directories
echo.

REM Check if 7-Zip is available for compression
where 7z >nul 2>&1
if %errorlevel% == 0 (
    echo Creating compressed package...
    7z a -tzip "%ZIP_FILE%" "%PACKAGE_DIR%\*" >nul
    if exist "%ZIP_FILE%" (
        echo Compressed package created: %ZIP_FILE%
        echo Package size: 
        for %%A in ("%ZIP_FILE%") do echo   %%~zA bytes
    )
) else (
    echo 7-Zip not found. Package created as directory only.
    echo To create a ZIP file, install 7-Zip or manually compress the folder.
)

echo.
echo ========================================================================
echo Deployment package ready!
echo.
echo Package Location: %PACKAGE_DIR%
if exist "%ZIP_FILE%" echo Compressed File: %ZIP_FILE%
echo.
echo To deploy:
echo 1. Copy the package to the target system
echo 2. Extract if compressed
echo 3. Run INSTALL.bat to verify prerequisites
echo 4. Follow QUICK-START.md for configuration
echo.
echo ========================================================================
echo.

pause

