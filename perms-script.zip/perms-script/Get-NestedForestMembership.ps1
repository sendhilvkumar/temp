﻿<#
.SYNOPSIS
    Performs fast, offline analysis of AD group memberships from a multi-domain/forest export.

.DESCRIPTION
    This script first consolidates data from multiple domain exports. It then resolves the full nested
    membership of a group, correctly tracing members across domain boundaries by matching Foreign Security
    Principal SIDs to their real objects.

.PARAMETER GroupName
    The name (sAMAccountName) of the top-level group to analyze.

.PARAMETER GroupDomain
    The short domain name (NetBIOS name) where the top-level group resides (e.g., 'CORP').

.PARAMETER FilePath
    The parent directory containing the individual domain export folders (e.g., "C:\temp\AD_Forest_Export").

.EXAMPLE
    .\Get-NestedForestMembership.ps1 -GroupName "R LSA CITRIX - Users" -GroupDomain "CORP" -FilePath "C:\temp\AD_Forest_Export"
#>
param (
    [Parameter(Mandatory = $true)]
    [string]$GroupName,
    [Parameter(Mandatory = $true)]
    [string]$GroupDomain,
    [Parameter(Mandatory = $true)]
    [string]$FilePath
)

# --- Step 1: Consolidate Data from All Domain Exports ---
Write-Host "Consolidating data from all domain exports in '$FilePath'..."
$subfolders = Get-ChildItem -Path $FilePath -Directory
if ($subfolders.Count -eq 0) {
    Write-Error "No domain subfolders found in '$FilePath'. Please run Export-ADForestData.ps1 first."
    return
}

# Import all data into single lists
$allGroupsData = $subfolders | ForEach-Object { Import-Csv -Path (Join-Path $_.FullName 'AllGroups.csv') }
$allObjectsData = $subfolders | ForEach-Object { Import-Csv -Path (Join-Path $_.FullName 'AllObjects.csv') }

# --- Step 2: Build Fast Lookup Tables (Hashtables) ---
Write-Host "Building in-memory lookup tables for analysis..."
# Key = DistinguishedName, Value = Object
$objectsByDN = $allObjectsData | Group-Object -Property DistinguishedName -AsHashTable -AsString
# Key = SID (as string), Value = Object
$objectsBySID = $allObjectsData | Group-Object -Property objectSid -AsHashTable -AsString
# Key = GroupDN, Value = List of Member objects
$membershipsByGroupDN = $allGroupsData | Where-Object { $_.MemberDN } | Group-Object -Property GroupDN -AsHashTable -AsString

# --- Step 3: Recursive Resolution Function (Offline, Multi-Domain Aware) ---
function Resolve-NestedForestGroup {
    param (
        [string]$currentObjectDN,
        [System.Collections.Generic.HashSet[string]]$processedGroupDNs,
        [System.Collections.Generic.HashSet[string]]$finalUserDNs
    )

    # Find the object in our master list
    $currentObject = $objectsByDN[$currentObjectDN]
    if ($null -eq $currentObject) { return } # Object not found

    $objectClass = $currentObject.objectClass[-1] # Get the most specific class

    # Base Case: If it's a user, add them and stop recursion.
    if ($objectClass -eq 'user') {
        $finalUserDNs.Add($currentObjectDN) | Out-Null
        return
    }

    # If it's a Foreign Security Principal, resolve it to its real object using SID
    if ($objectClass -eq 'foreignSecurityPrincipal') {
        $realObject = $objectsBySID[$currentObject.objectSid]
        if ($null -ne $realObject) {
            # Recurse on the *real* object we just found
            Resolve-NestedForestGroup -currentObjectDN $realObject.DistinguishedName -processedGroupDNs $processedGroupDNs -finalUserDNs $finalUserDNs
        }
        return
    }

    # Recursive Case: If it's a group, process its members.
    if ($objectClass -eq 'group') {
        # Circular reference check
        if ($processedGroupDNs.Contains($currentObjectDN)) { return }
        $processedGroupDNs.Add($currentObjectDN) | Out-Null

        $directMembers = $membershipsByGroupDN[$currentObjectDN]
        if ($null -eq $directMembers) { return }

        foreach ($member in $directMembers) {
            # Recurse for each member
            Resolve-NestedForestGroup -currentObjectDN $member.MemberDN -processedGroupDNs $processedGroupDNs -finalUserDNs $finalUserDNs
        }
    }
}

# --- Step 4: Execute the Analysis ---
Write-Host "Analyzing membership for group '$GroupName' in domain '$GroupDomain'..."
# Find the starting group object
$startGroup = $allObjectsData | Where-Object { $_.sAMAccountName -eq $GroupName -and $_.Domain -eq $GroupDomain } | Select-Object -First 1

if (-not $startGroup) {
    Write-Error "Group '$GroupName' in domain '$GroupDomain' not found in the exported data."
    return
}

$finalUserDNs = [System.Collections.Generic.HashSet[string]]::new()
$processedGroupDNs = [System.Collections.Generic.HashSet[string]]::new()

# Start the recursive search from the top-level group
Resolve-NestedForestGroup -currentObjectDN $startGroup.DistinguishedName -processedGroupDNs $processedGroupDNs -finalUserDNs $finalUserDNs

# --- Step 5: Output the Results ---
if ($finalUserDNs.Count -eq 0) {
    Write-Warning "No nested user members found for group '$GroupName'."
    return
}

Write-Host "---"
Write-Host "Found $($finalUserDNs.Count) unique nested users in '$GroupName'."
Write-Host "---"

# Retrieve the full user objects and display them
$finalUsers = $finalUserDNs | ForEach-Object { $objectsByDN[$_] }
$finalUsers | Select-Object Domain, sAMAccountName, Name | Format-Table

