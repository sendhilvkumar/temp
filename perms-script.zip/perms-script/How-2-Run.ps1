﻿How to Use the Multi-Domain Solution
Run the Export Script for Each Domain:
Identify a domain controller for each domain you need to query (e.g., dc1.corp.com, dc1.europe.com).
Run Export-ADForestData.ps1 for each one, pointing them all to the same parent folder.
powershell
# In one PowerShell window
.\Export-ADForestData.ps1 -Server 'dc1.corp.com' -FilePath "C:\AD_Forest_Data"
.\Export-ADForestData.ps1 -Server 'dc1.europe.com' -FilePath "C:\AD_Forest_Data"
.\Export-ADForestData.ps1 -Server 'dc1.asia.com' -FilePath "C:\AD_Forest_Data"
This will create a folder structure like:
Plain Text
C:\AD_Forest_Data\
├── corp.com\
│   ├── AllGroups.csv
│   └── AllObjects.csv
├── europe.com\
│   ├── AllGroups.csv
│   └── AllObjects.csv
...
Run the Analysis Script:
Once all exports are complete, run the analysis script, specifying the group's name, its home domain, and the parent folder containing all the data.
powershell
.\Get-NestedForestMembership.ps1 -GroupName "R LSA CITRIX - Users" -GroupDomain "corp.com" -FilePath "C:\AD_Forest_Data"
This robust, two-stage process is the industry-standard way to handle this complex task. It is scalable, fast, and accurate across even the most complicated multi-domain Active Directory forests.